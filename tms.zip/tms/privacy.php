<?php
session_start();
error_reporting(0);
include('includes/config.php');
?><!DOCTYPE HTML>
<html>
<head>
<title>Privacy Policy | Tour Guide Connect System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
    new WOW().init();
</script>
<style>
:root {
    --royal-blue: #002366;
    --dark-blue: #000080;
    --white: #ffffff;
    --black: #000000;
    --grey: #f8f9fa;
}

.privacy-hero {
    background: var(--royal-blue);
    color: var(--white);
    padding: 12rem 0 4rem;
    position: relative;
    overflow: hidden;
    margin-top: -1px;
}
.privacy-hero::after {
    content: '';
    position: absolute;
    bottom: -90px;
    left: 0;
    width: 100%;
    height: 100px;
    background: var(--white);
    transform: skewY(-3deg);
}
.privacy-content {
    background: var(--white);
    padding: 4rem 0;
    position: relative;
    z-index: 1;
}

.section-title {
    color: var(--royal-blue);
    border-left: 4px solid var(--dark-blue);
    padding-left: 1rem;
    margin: 3rem 0 1.5rem;
    font-size: 2rem;
    font-weight: 600;
}

.privacy-text {
    margin-bottom: 2.5rem;
    line-height: 1.8;
    color: #333;
}

.privacy-text h4 {
    color: var(--dark-blue);
    margin-bottom: 1rem;
    font-size: 1.3rem;
}

.privacy-list {
    margin: 1.5rem 0;
    padding-left: 1.5rem;
}

.privacy-list li {
    margin-bottom: 0.8rem;
    line-height: 1.6;
}

.contact-banner {
    background: linear-gradient(45deg, var(--royal-blue), var(--dark-blue));
    color: var(--white);
    padding: 3rem;
    border-radius: 10px;
    margin: 4rem 0;
    text-align: center;
}

.contact-banner h3 {
    font-size: 1.75rem;
    margin-bottom: 1rem;
}

.contact-banner p {
    font-size: 1.1rem;
    margin-bottom: 2rem;
}

.contact-banner a {
    display: inline-block;
    background: var(--white);
    color: var(--royal-blue);
    padding: 0.8rem 2.5rem;
    border-radius: 50px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    border: 2px solid transparent;
}

.contact-banner a:hover {
    background: transparent;
    color: var(--white);
    border-color: var(--white);
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .privacy-hero {
        padding: 10rem 0 4rem;
    }
    
    .section-title {
        font-size: 1.75rem;
    }
}

@media (max-width: 768px) {
    .privacy-hero {
        padding: 8rem 0 3rem;
    }
    
    .privacy-content {
        padding: 2.5rem 0;
    }
    
    .contact-banner {
        padding: 2rem;
        margin: 3rem 0;
    }
}

@media (max-width: 576px) {
    .privacy-hero {
        padding: 7rem 0 2.5rem;
    }
    
    .section-title {
        font-size: 1.5rem;
    }
}
</style>
</head>
<body>

<?php include('includes/header.php');?>

<div class="privacy-hero text-center">
    <div class="container">
        <h1 class="display-4 mb-4">Privacy Policy</h1>
        <p class="lead">Protecting Your Journey, Securing Your Data</p>
    </div>
</div>

<main class="privacy-content">
    <div class="container">
        <section class="mb-5">
            <h2 class="section-title">Data Collection & Use</h2>
            
            <div class="privacy-text">
                <h4>Information We Collect</h4>
                <p>At Tour Guide Connect System, we collect various types of information to provide and improve our services to you:</p>
                <ul class="privacy-list">
                    <li><strong>Personal identification information:</strong> This includes your name, email address, phone number, and other contact details when you register for our services or make inquiries.</li>
                    <li><strong>Travel preferences and booking details:</strong> We collect information about your travel plans, destinations, preferred activities, and any special requirements to help match you with suitable tour guides.</li>
                    <li><strong>Payment and transaction information:</strong> When you make bookings or payments through our platform, we process payment details to complete your transactions securely.</li>
                    <li><strong>Communication records:</strong> We maintain records of your communications with our team and the tour guides you connect with through our platform.</li>
                    <li><strong>Usage data:</strong> We collect information about how you interact with our website and services to improve user experience and platform functionality.</li>
                </ul>
            </div>

            <div class="privacy-text">
                <h4>Data Protection</h4>
                <p>We take the security of your personal information seriously and implement comprehensive measures to protect your data:</p>
                <ul class="privacy-list">
                    <li><strong>SSL encryption:</strong> All data transmitted between your browser and our servers is encrypted using industry-standard Secure Socket Layer (SSL) technology.</li>
                    <li><strong>Regular security audits:</strong> Our systems undergo frequent security assessments to identify and address potential vulnerabilities.</li>
                    <li><strong>Secure server infrastructure:</strong> We host our platform on protected servers with advanced firewall protection and intrusion detection systems.</li>
                    <li><strong>Limited access:</strong> Only authorized personnel with specific needs can access your personal information, and all access is logged and monitored.</li>
                    <li><strong>Data minimization:</strong> We only collect information that is necessary for providing our services and delete data when it's no longer required.</li>
                </ul>
                <p>While we implement these robust security measures, please remember that no method of transmission over the Internet or method of electronic storage is 100% secure. We cannot guarantee absolute security but we continuously work to maintain the highest standards of data protection.</p>
            </div>
        </section>

        <section class="mb-5">
            <h2 class="section-title">User Rights</h2>
            
            <div class="privacy-text">
                <h4>Data Access</h4>
                <p>You have the right to request a copy of all personal data we hold about you in a standard digital format. This includes:</p>
                <ul class="privacy-list">
                    <li>Your account registration details</li>
                    <li>Booking and transaction history</li>
                    <li>Communication records with our platform</li>
                    <li>Any preferences you've set in your account</li>
                </ul>
                <p>To request your data, please contact our Data Protection Officer using the information provided below. We will provide your data within 30 days of receiving a verified request.</p>
            </div>

            <div class="privacy-text">
                <h4>Data Correction</h4>
                <p>You can update or modify your personal information through your account settings at any time. If you encounter any difficulties or need to correct information that isn't editable through your account, please contact our support team.</p>
                <p>We may ask you to verify your identity before making certain changes to ensure the security of your account. This verification process helps prevent unauthorized access to your personal information.</p>
            </div>
            
            <div class="privacy-text">
                <h4>Data Deletion</h4>
                <p>You may request deletion of your personal data from our systems, subject to certain legal obligations we may have to retain some information. When you request account deletion:</p>
                <ul class="privacy-list">
                    <li>We will permanently remove your personal information from our active databases</li>
                    <li>Some anonymized data may be retained for analytical purposes</li>
                    <li>Transaction records required for financial reporting may be kept as required by law</li>
                </ul>
            </div>
        </section>

        <div class="contact-banner text-center">
            <h3 class="mb-4">Privacy Concerns?</h3>
            <p class="mb-4">Contact our Data Protection Officer</p>
            <a class="fa" href="enquiry.php"><B> Contact Us</B></a>
        </div>
    </div>
</main>

<?php 
include('includes/footer.php');
include('includes/signup.php');
include('includes/signin.php');
include('includes/write-us.php');
?>

<!-- Required Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

</body>
</html>