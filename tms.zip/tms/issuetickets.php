<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0) {    
    header('location:index.php');
}
else {
?>
<!DOCTYPE HTML>
<html>
<head>
<title>UTRS | User Travel Recommendation System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />

<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
    new WOW().init();
</script>

<style>
    /* Main Container */
    .privacy {
        margin-top: 120px;
        padding: 40px 0;
		height: 900px;
    }
    
    .container {
        max-width: 1600px;
        margin: 0 auto;
        padding: 0 20px;
    }
    
    /* Page Title */
    h3.wow {
        color: #004e92;
        font-size: 28px;
        margin-top: 5px;
        text-align: center;
        padding-bottom: 15px;
        border-bottom: 2px solid #f0f0f0;
    }
    
    /* Cards Grid Layout */
    .tickets-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 25px;
        margin-top: 30px;
		
    }
    
    /* Ticket Card Styling */
    .ticket-card {
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        padding: 20px;
        transition: transform 0.3s ease;
    }
    
    .ticket-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    
    .ticket-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        padding-bottom: 15px;
        border-bottom: 1px solid #eee;
    }
    
    .ticket-number {
        font-weight: bold;
        color: #004e92;
        font-size: 18px;
    }
    
    .ticket-id {
        background: #f0f7ff;
        color: #004e92;
        padding: 3px 10px;
        border-radius: 20px;
        font-size: 14px;
    }
    
    .ticket-issue {
        font-weight: 600;
        color: #333;
        margin-bottom: 10px;
        font-size: 16px;
    }
    
    .ticket-desc {
        color: #555;
        line-height: 1.5;
        margin-bottom: 15px;
    }
    
    .ticket-dates {
        display: flex;
        justify-content: space-between;
        font-size: 14px;
        color: #666;
        margin-top: 15px;
        padding-top: 15px;
        border-top: 1px solid #eee;
    }
    
    .ticket-remark {
        background: #f9f9f9;
        padding: 10px;
        border-radius: 5px;
        margin-top: 15px;
        border-left: 3px solid #004e92;
    }
    
    .remark-title {
        font-weight: 600;
        color: #004e92;
        margin-bottom: 5px;
        display: block;
    }
    
    /* Message Styling */
    .errorWrap {
        padding: 15px;
        margin: 0 0 25px 0;
        background: #f8d7da;
        border-left: 4px solid #dc3545;
        color: #721c24;
        border-radius: 4px;
    }
    
    .succWrap {
        padding: 15px;
        margin: 0 0 25px 0;
        background: #d4edda;
        border-left: 4px solid #28a745;
        color: #155724;
        border-radius: 4px;
    }
    
    /* No Tickets */
    .no-tickets {
        text-align: center;
        color: #666;
        padding: 40px;
        grid-column: 1 / -1;
    }
    
    @media (max-width: 768px) {
        .privacy {
            margin-top: 100px;
        }
        
        .tickets-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
</head>
<body>

<?php include('includes/header.php');?>

<!--- /banner-1 ---->
<!--- privacy ---->
<div class="privacy">
    <div class="container">
        <h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Issue Tickets</h3>
        <form name="chngpwd" method="post" onSubmit="return valid();">
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
            
            <div class="tickets-grid">
                <?php 
                $uemail = $_SESSION['login'];
                $sql = "SELECT * from tblissues where UserEmail=:uemail";
                $query = $dbh->prepare($sql);
                $query->bindParam(':uemail', $uemail, PDO::PARAM_STR);
                $query->execute();
                $results = $query->fetchAll(PDO::FETCH_OBJ);
                $cnt = 1;
                
                if($query->rowCount() > 0) {
                    foreach($results as $result) { 
                ?>
                <div class="ticket-card wow fadeInUp" data-wow-delay="0.<?php echo $cnt; ?>s">
                    <div class="ticket-header">
                        <span class="ticket-number">Ticket #<?php echo htmlentities($cnt); ?></span>
                        <span class="ticket-id">#TKT-<?php echo htmlentities($result->id); ?></span>
                    </div>
                    
                    <div class="ticket-issue">Issues - <?php echo htmlentities($result->Issue); ?></div>
                    <div class="ticket-desc">Description - <?php echo htmlentities($result->Description); ?></div>
                    
                    <div class="ticket-dates">
                        <span>Regi. Date: <?php echo htmlentities($result->PostingDate); ?></span>
                        <span>Remark Date: <?php echo htmlentities($result->AdminremarkDate); ?></span>
                    </div>
                    
                    <?php if(!empty($result->AdminRemark)) { ?>
                    <div class="ticket-remark">
                        <span class="remark-title">Admin Rmark:</span>
                        <?php echo htmlentities($result->AdminRemark); ?>
                    </div>
                    <?php } ?>
                </div>
                <?php 
                    $cnt++;
                    } 
                } else { 
                ?>
                <div class="no-tickets">
                    <i class="fa fa-ticket" style="font-size: 50px; color: #ddd; margin-bottom: 20px;"></i>
                    <h4>No Tickets Found</h4>
                    <p>You haven't submitted any support tickets yet.</p>
                </div>
                <?php } ?>
            </div>
        </form>
    </div>
</div>
<!--- /privacy ---->
<!--- footer-top ---->
<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>            
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>            
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>
<?php } ?>