<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TGCS | Package List</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />

<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
    new WOW().init();
</script>
<!--//end-animate-->
<style>
:root {
    --royal-blue: #2b5876;
    --mint-green: #4e937a;
    --golden: #FFD700;
    --gradient-blue-mint: linear-gradient(135deg, var(--royal-blue) 0%, var(--mint-green) 100%);
}

/* Main Container */
.rooms {
    padding: 50px 0;
    background: #f8f9fa;
    position: relative;
    overflow: hidden;
}

.rooms .container {
    position: relative;
    z-index: 2;
}

/* Heading Styles */
.rooms h3 {
    color: var(--royal-blue);
    font-size: 36px;
    font-weight: 700;
    margin-top: 70px;
    text-align: center;
    position: relative;
    padding-bottom: 15px;
}

.rooms h3::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 100px;
    height: 4px;
    background: var(--golden);
    animation: lineExpand 1.5s ease-out forwards;
}

@keyframes lineExpand {
    0% { width: 0; }
    100% { width: 100px; }
}

/* Horizontal Scrolling Container */
/* Horizontal Scrolling Container */
.horizontal-scroll-container {
    width: 100%;
    overflow-x: auto;
    padding: 40px 0 60px;
    -webkit-overflow-scrolling: touch;
    position: relative;
    margin-left: 0; /* Ensure no left margin */
}

/* Remove the left fade effect since we want full visibility */
.horizontal-scroll-container::before {
    display: none; /* Remove left fade */
}

/* Keep right fade for when scrolling */
.horizontal-scroll-container::after {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    width: 60px;
    z-index: 2;
    background: linear-gradient(270deg, rgba(248,249,250,1) 0%, rgba(248,249,250,0) 100%);
    pointer-events: none;
}

.scroll-wrapper {
    display: inline-flex;
    gap: 30px;
    padding: 0 20px 0 40px; /* More padding on left than right */
    animation: slideInFromLeft 0.8s ease-out;
    margin-left: 0; /* Remove any left margin */
}

@keyframes slideInFromLeft {
    0% { transform: translateX(20px); opacity: 0; } /* Start closer to final position */
    100% { transform: translateX(0); opacity: 1; }
}

/* Package Card Styles */
.package-card {
    min-width: 320px;
    max-width: 320px;
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    overflow: hidden;
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
    transform: translateY(0);
    animation: cardFloat 3s ease-in-out infinite alternate;
}

@keyframes cardFloat {
    0% { transform: translateY(0); }
    100% { transform: translateY(-10px); }
}

.package-card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    animation: none;
}

.package-image {
    height: 200px;
    overflow: hidden;
    position: relative;
}

.package-image::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to bottom, rgba(0,0,0,0.1), rgba(0,0,0,0.3));
    z-index: 1;
}

.package-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.6s ease;
}

.package-card:hover .package-image img {
    transform: scale(1.1);
}

.package-details {
    padding: 20px;
    flex-grow: 1;
    position: relative;
}

.package-details h4 {
    color: var(--royal-blue);
    font-size: 22px;
    margin-bottom: 15px;
    font-weight: 700;
    position: relative;
    padding-bottom: 10px;
}

.package-details h4::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 40px;
    height: 3px;
    background: var(--golden);
    transition: width 0.4s ease;
}

.package-card:hover .package-details h4::after {
    width: 100px;
}

.package-details h6 {
    color: var(--mint-green);
    font-size: 16px;
    margin-bottom: 10px;
    font-weight: 600;
}

.package-details p {
    color: #555;
    font-size: 14px;
    line-height: 1.6;
    margin-bottom: 10px;
}

.package-price {
    padding: 0 20px 20px;
    text-align: right;
}

.package-price h5 {
    background: var(--gradient-blue-mint);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-size: 24px;
    font-weight: 800;
    margin-bottom: 15px;
}

.view {
    background: var(--gradient-blue-mint);
    color: #fff !important;
    padding: 12px 30px;
    border-radius: 8px;
    text-transform: uppercase;
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    transition: all 0.4s ease;
    display: inline-block;
    border: none;
    position: relative;
    overflow: hidden;
}

.view::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transition: 0.6s;
}

.view:hover::before {
    left: 100%;
}

.view:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(43,88,118,0.3);
}

/* Scrollbar Styling */
.horizontal-scroll-container::-webkit-scrollbar {
    height: 8px;
}

.horizontal-scroll-container::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.horizontal-scroll-container::-webkit-scrollbar-thumb {
    background: var(--mint-green);
    border-radius: 10px;
    transition: background 0.3s;
}

.horizontal-scroll-container::-webkit-scrollbar-thumb:hover {
    background: var(--royal-blue);
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .rooms h3 {
        font-size: 28px;
    }
    
    .package-card {
        min-width: 280px;
    }
    
    .package-details {
        padding: 15px;
    }
    
    .package-price {
        padding: 0 15px 15px;
    }
    
    .horizontal-scroll-container::before,
    .horizontal-scroll-container::after {
        width: 30px;
    }
}

@media (max-width: 480px) {
    .rooms h3 {
        font-size: 24px;
        margin-bottom: 20px;
    }
    
    .package-card {
        min-width: 260px;
    }
    
    .scroll-wrapper {
        gap: 20px;
        padding: 0 20px;
    }
}
</style>
</head>
<body>
<?php include('includes/header.php');?>

<div class="rooms">
    <div class="container">
        <h3 class="wow fadeInUp">Package List</h3>
        
        <div class="horizontal-scroll-container wow fadeIn" data-wow-delay="0.3s">
            <div class="scroll-wrapper">
                <?php 
                $sql = "SELECT * from tbltourpackages";
                $query = $dbh->prepare($sql);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);
                $cnt=1;
                if($query->rowCount() > 0) {
                    foreach($results as $result) {    
                ?>
                <div class="package-card wow fadeInUp" data-wow-delay="<?php echo $cnt * 0.1 + 0.3 ?>s">
                    <div class="package-image">
                        <img src="admin/pacakgeimages/<?php echo htmlentities($result->PackageImage);?>" class="img-responsive" alt="">
                    </div>
                    <div class="package-details">
                        <h4><?php echo htmlentities($result->PackageName);?></h4>
                        <h6><?php echo htmlentities($result->PackageType);?></h6>
                        <p><b>Location:</b> <?php echo htmlentities($result->PackageLocation);?></p>
                        <p><b>Features:</b> <?php echo htmlentities($result->PackageFetures);?></p>
                    </div>
                    <div class="package-price">
                        <h5>USD <?php echo htmlentities($result->PackagePrice);?></h5>
                        <a href="package-details.php?pkgid=<?php echo htmlentities($result->PackageId);?>" class="view">Details</a>
                    </div>
                </div>
                <?php $cnt++; }} ?>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>            
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>            
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>            
<!-- //write us -->
</body>

</html>