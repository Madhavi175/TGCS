<div class="top-header" style="height: 100px; position: fixed; width: 100%; background: linear-gradient(45deg, #000428, #004e92); z-index: 1000; border-bottom-left-radius: 50px; border-bottom-right-radius: 50px;">
  <div class="container" style="display: flex; justify-content: space-between; align-items: center; padding: 20px;">
    
    <!-- Site Name (Independent) -->
    <a href="index.php" class="site-name">Tour Guide Connect System</a>

    <!-- Admin Tour Group (Without Title) -->
    <!-- <div class="admin-tour-group" style="display: flex; justify-content: center; align-items: center; gap: 20px; background: lavender; padding: 10px; border-radius: 20px;">
      <a href="index.php" class="home-icon" style="font-size: 18px; color: white;"><i class="fa fa-home"></i></a>
    </div> -->

    <!-- Dropdown -->
    <div class="dropdown">
      <button class="dropbtn">Setting</button>
      <div class="dropdown-content">
        <?php if($_SESSION['login']) { ?>
          <a href="#">Welcome : <?php echo htmlentities($_SESSION['login']);?></a>
          <a href="profile.php">My Profile</a>
          <a href="issuetickets.php">Issue Ticket</a>
          <a href="tour-history.php">Tour History</a>
          <a href="change-password.php">Change Password</a>
          <a href="logout.php">Logout</a>
                  <?php } else { ?>
          <a href="admin/index.php">Admin Login</a>
          <a href="#">Toll Number : 222-77777</a>
          <a href="#" data-toggle="modal" data-target="#myModal">Sign Up</a>
          <a href="#" data-toggle="modal" data-target="#myModal4">Sign In</a>
        <?php } ?>
      </div>
    </div>

  </div>
</div>

<!-- Open Circular Sidebar Button -->
<span class="openbtn" onclick="toggleNav()" style="color: white;">&#9776;</span>

<!-- Sidebar Navigation -->
<div id="circular-sidebar" class="circular-sidebar">
  <a href="javascript:void(0)" class="closebtn" onclick="toggleNav()">&times;</a>
  <a href="index.php">Home</a>
  <a href="about.php">About</a>
  <a href="package-list.php">Tour Packages</a>
  <a href="privacy.php">Privacy Policy</a>
  <a href="terms.php">Terms of Use</a>
  <!-- <a href="page.php?type=contact">Contact Us</a> -->
  <?php if($_SESSION['login']) { ?>
    <a href="#" data-toggle="modal" data-target="#myModal3">Need Help? / Write Us</a>
  <?php } else { ?>
    <a href="enquiry.php">Enquiry</a>
  <?php } ?>
</div>
<!-- Sidebar CSS -->
<style>
 .site-name {
    font-size: 35px;
    font-weight: bold;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    text-transform: uppercase;
    background: linear-gradient(45deg, #1E90FF, #98FF98); /* Blue to Mint Gradient */
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3);
    text-decoration: none;
    
}
.top-header {
    position: relative;
    z-index: 1000;
    margin-top: 0 !important;
    top: 0 !important;
}
 /* Sidebar Main Container */
 .circular-sidebar {
    position: fixed;
    left: -350px; /* Initially hidden */
    top: 50%;
    transform: translateY(-50%);
    width: 400px;
    height: 400px;
    background: linear-gradient(45deg, #000428, #004e92);
        border-radius: 50%;
    overflow: hidden;
    transition: 0.5s ease-in-out;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 1000;
   
  }

  /* Sidebar Open Animation */
  .circular-sidebar.open {
    left: 10px; /* Moves into view */
  }

  /* Sidebar Links */
  .circular-sidebar a {
    text-decoration: none;
    color: white;
    font-size: 20px;
    padding: 12px;
    transition: color 0.3s ease-in-out, transform 0.3s ease-in-out;
    position: relative;
  }

  /* Sidebar Hover Effect */
  .circular-sidebar a:hover {
    color: gold;
    transform: scale(1.1);
  }

  /* Golden Underline Animation */
  .circular-sidebar a::after {
    content: "";
    display: block;
    width: 0%;
    height: 3px;
    background: gold;
    transition: width 0.4s ease-in-out;
  }

  /* Expanding Line on Hover */
  .circular-sidebar a:hover::after {
    width: 100%;
  }

  /* Close Button */
  .circular-sidebar .closebtn {
    position: absolute;
    top: 10px;
    right: 60px;
    font-size: 40px;
    color: red;
    cursor: pointer;
    transition: transform 0.3s ease-in-out, color 0.3s ease-in-out;
  }

  /* Close Button Hover Animation */
  .circular-sidebar .closebtn:hover {
    color: yellow;
    transform: rotate(180deg);
  }

  /* Open Button */
  .openbtn {
    font-size: 30px;
    cursor: pointer;
    position: fixed;
    left: 20px;
    top: 20px;
    z-index: 1001;
  }
  .dropbtn {
    background-color: #000428;
    color: white;
    padding: 10px;
    font-size: 16px;
    border: none;
    cursor: pointer;
    border-radius: 10px;
  }
  .dropdown {
    position: relative;
    display: inline-block;
  }
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: white;
    min-width: 160px;
    box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
    z-index: 1;
    border-radius: 10px;
  }
  .dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }
  .dropdown-content a:hover {background-color: #ddd;}
  .dropdown:hover .dropdown-content {display: block;}
  /* Mobile Responsive Styles */
@media screen and (max-width: 768px) {
    .top-header {
        height: 70px;
        border-bottom-left-radius: 30px;
        border-bottom-right-radius: 30px;
    }

    .container {
        padding: 10px 15px !important;
        gap: 10px;
    }

    .site-name {
        font-size: 20px !important;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 60vw;
        text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
    }

    /* Dropdown adjustments */
    .dropdown {
        position: static;
        margin-left: auto;
    }

    .dropbtn {
        padding: 8px 12px;
        font-size: 14px;
        border-radius: 8px;
    }

    .dropdown-content {
        right: 10px;
        left: auto !important;
        min-width: 180px;
        top: 50px !important;
    }

    /* Sidebar adjustments */
    .circular-sidebar {
        width: 100vw;
        height: 100vh;
        border-radius: 0;
        left: -100vw;
        top: 0;
        transform: none;
        justify-content: flex-start;
        padding-top: 80px;
    }

    .circular-sidebar.open {
        left: 0;
    }

    .circular-sidebar a {
        font-size: 18px;
        padding: 15px;
        width: 100%;
        text-align: center;
    }

    .openbtn {
        left: 10px;
        top: 15px;
        font-size: 24px;
        background: rgba(0,0,0,0.3);
        padding: 5px 10px;
        border-radius: 5px;
    }

    .circular-sidebar .closebtn {
        top: 20px;
        right: 20px;
        font-size: 30px;
    }
}

@media screen and (max-width: 480px) {
    .site-name {
        font-size: 18px !important;
        max-width: 50vw;
    }

    .dropbtn {
        padding: 6px 10px;
        font-size: 13px;
    }

    .dropdown-content {
        min-width: 160px;
        top: 45px !important;
    }

    .circular-sidebar a {
        font-size: 16px;
        padding: 12px;
    }
}
</style>

<!-- Sidebar JavaScript -->
<script>
  function toggleNav() {
    var sidebar = document.getElementById("circular-sidebar");
    sidebar.classList.toggle("open");
  }
</script>