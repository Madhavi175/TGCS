<?php
session_start();
if(isset($_POST['signin']))
{
$email=$_POST['email'];
$password=md5($_POST['password']);
$sql ="SELECT EmailId,Password FROM tblusers WHERE EmailId=:email and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['login']=$_POST['email'];
echo "<script type='text/javascript'> document.location = 'thankyou.php'; </script>";
} else{
    echo "<script>alert('Invalid Details');</script>";
}
}
?>
<style>
/* Add Font Awesome */
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');

#myModal4 .modal-content {
    background: #fff;
    border-radius: 15px;
    padding: 20px;
}

#myModal4 .login {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

/* Compact Social Buttons */
#myModal4 .social-buttons {
    margin-top: 25px;
    text-align: center;
}

#myModal4 .social-btn {
    display: inline-block;
    width: 150px;
    padding: 10px 15px;
    margin: 5px;
    border-radius: 25px;
    color: white !important;
    text-decoration: none;
    font-size: 14px;
    transition: transform 0.3s ease;
    background: linear-gradient(45deg, #98FF98, #000000, #007BFF);
}

#myModal4 .social-btn:hover {
    transform: translateY(-2px);
}

#myModal4 .fb-btn {
    background: #3b5998;}

#myModal4 .google-btn {
    background: #dd4b39;
}

#myModal4 .social-btn i {
    margin-right: 8px;
    font-size: 16px;
}

/* Compact Form Fields */
#myModal4 .login-right {
    margin-top: -15px;
}

#myModal4 input[type="text"],
#myModal4 input[type="password"] {
    width: 100%;
    padding: 10px 15px;
    margin-bottom: 12px;
    border: 1px solid;
    border-radius: 20px;
    font-size: 14px;
}

#myModal4 input[type="submit"] {
    background: linear-gradient(45deg, #007bff, #000000);
    color: white;
    padding: 12px;
    width: 100%;
    border: none;
    border-radius: 20px;
    cursor: pointer;
    transition: opacity 0.3s;
}

#myModal4 input[type="submit"]:hover {
    opacity: 0.9;
}

#myModal4 h4 {
    text-align: right;
    margin: 10px 0;
}

#myModal4 h4 a {
    /* color: #007bff; */
    font-size: 13px;
}
</style>

<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content modal-info">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>                        
            </div>
            <div class="modal-body modal-spa">
                <div class="login-grids">
                    <div class="login">
                        <div class="login-right">
                            <form method="post">
                                <h3>Sign In</h3>
                                <input type="text" name="email" placeholder="Email" required>
                                <input type="password" name="password" placeholder="Password" required>
                                <input type="submit" name="signin" value="SIGN IN">
                                <h4><a href="forgot-password.php">Forgot Password?</a></h4>
                            </form>
                            
                            <div class="social-buttons">
                                <a href="https://www.facebook.com/" class="social-btn fb-btn">
                                    <i class="fab fa-facebook-f"></i>Facebook
                                </a>
                                <a href="https://accounts.google.com/v3/signin/identifier?continue=https%3A%2F%2Faccounts.google.com%2F&followup=https%3A%2F%2Faccounts.google.com%2F&ifkv=AXH0vVurKE9GAwNTtC0yZklH4Qt-OrR6IaLxZPExi_NSdTqUmXSkSqaim6Q0xknL8zWUgpxXuF3i&passive=12096
                                00&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S2048721337%3A1745434371160186" class="social-btn google-btn">
                                    <i class="fab fa-google"></i>Google
                                </a>
                            </div>
                        </div>
                    </div>
                    <p style="font-size:12px; margin-top:15px;">By logging in you agree to our 
                        <a href="terms.php">Terms</a> and 
                        <a href="privacy.php">Privacy</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>