<?php
error_reporting(0);
if(isset($_POST['submit']))
{
$issue=$_POST['issue'];
$description=$_POST['description'];
$email=$_SESSION['login'];
$sql="INSERT INTO  tblissues(UserEmail,Issue,Description) VALUES(:email,:issue,:description)";
$query = $dbh->prepare($sql);
$query->bindParam(':issue',$issue,PDO::PARAM_STR);
$query->bindParam(':description',$description,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$_SESSION['msg']="Info successfully submited ";
echo "<script type='text/javascript'> document.location = 'thankyou.php'; </script>";
}
else 
{
$_SESSION['msg']="Something went wrong. Please try again.";
echo "<script type='text/javascript'> document.location = 'thankyou.php'; </script>";
}
}
?>	
<style>
.help-modal {
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
    color: #2d3748;
}

.modal-content {
    border: none;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.1);
    overflow: hidden;
}

.modal-header {
    background: #2563eb;
    padding: 1.5rem;
    border-bottom: none;
}

.modal-title {
    color: white;
    font-weight: 600;
    font-size: 1.5rem;
}

.btn-close {
    color: white;
    opacity: 0.8;
    text-shadow: none;
    transition: opacity 0.2s ease;
}

.btn-close:hover {
    opacity: 1;
    color: white;
}

.modal-spa {
    padding: 2rem;
    background: #f8fafc;
}

.help-heading {
    color: #1e40af;
    font-weight: 600;
    font-size: 1.25rem;
    margin-bottom: 1.5rem;
    text-align: center;
}

.form-label {
    color: #475569;
    font-weight: 500;
    margin-bottom: 0.5rem;
    font-size: 0.875rem;
}

/* .form-control {
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    padding: 0.75rem 1rem;
    transition: all 0.2s ease;
    background: white;
} */

/* .form-control:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
} */
/* 
.form-select {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='%232563eb' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
} */

textarea.form-control {
    min-height: 120px;
    resize: vertical;
}

.submit-btn {
    background: #2563eb;
    color: white;
    padding: 1rem 2rem;
    border-radius: 8px;
    font-weight: 600;
    text-transform: none;
    letter-spacing: -0.25px;
    transition: all 0.2s ease;
    width: 100%;
    border: none;
    margin-top: 1rem;
}

.submit-btn:hover {
    background: #1d4ed8;
    transform: translateY(-1px);
}

.submit-btn:active {
    transform: translateY(0);
}

.input-group {
    position: relative;
    margin-bottom: 1.5rem;
}

.input-icon {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
}

/* Add smooth modal transitions */
.modal.fade .modal-content {
    transform: translateY(-50px);
    transition: transform 0.3s ease-out;
}

.modal.show .modal-content {
    transform: translateY(0);
}

</style>

<!-- Add Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>

<div class="modal fade help-modal" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="helpModalLabel">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="helpModalLabel">Support Request</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: white; font-size: 1.75rem;">&times;</span>
                </button>
            </div>
            <section>
                <form name="help" method="post">
                    <div class="modal-body modal-spa">
                        <h4 class="help-heading">How Can We Assist You?</h4>
                        
                        <div class="form-group">
                            <label class="form-label" for="issue-type">Issue Category</label>
                            <div class="input-group">
                                <select class="form-control form-select" id="issue-type" name="issue" required>
                                    <option value="">Select issue type</option>
                                    <option value="Booking Issues">Booking Assistance</option>
                                    <option value="Cancellation">Cancellation Request</option>
                                    <option value="Refund">Refund Inquiry</option>
                                    <option value="Other">Other Question</option>
                                </select>
                                <i class="fas fa-chevron-down input-icon"></i>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="issue-description">Detailed Description</label>
                            <textarea class="form-control" 
                                    id="issue-description" 
                                    name="description" 
                                    placeholder="Please provide specific details about your request..."
                                    required></textarea>
                        </div>

                        <div class="form-group mb-0">
                            <button type="submit" name="submit" class="submit-btn">
                                <i class="fas fa-paper-plane mr-2"></i>Submit Request
                            </button>
                        </div>
                    </div>
                </form>
            </section>
        </div>
    </div>
</div>

<!-- Add Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">