<!DOCTYPE HTML>
<html>
<head>
<title>UTRS | User Travel Recommendation System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
  new WOW().init();
</script>
<style>
  /* Error and Success Messages */
  .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
  }
  .succWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
  }

  /* Form Container */
  .form-container {
    position: relative;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background: #fff;
    border: 2px solid transparent;
    border-radius: 10px;
    overflow: hidden;
  }

  /* Gold Moving Border */
  .form-container::before {
    content: '';
    position: absolute;
    top: -2px;
    left: -100%;
    width: 200%;
    height: 2px;
    background: linear-gradient(90deg, transparent, gold, transparent);
    animation: moveBorder 3s linear infinite;
  }

  @keyframes moveBorder {
    0% {
      transform: translateX(-50%);
    }
    100% {
      transform: translateX(50%);
    }
  }

  /* Form Inputs */
  .form-container input,
  .form-container textarea {
    width: 100%;
    padding: 10px 0;
    margin: 10px 0;
    border: none;
    border-bottom: 2px solid #007bff; /* Blue underline */
    background: transparent;
    font-size: 16px;
    outline: none;
  }

  .form-container textarea {
    resize: vertical;
  }

  .form-container button {
    width: 100%;
    padding: 10px;
    background: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    margin-top: 20px;
  }

  .form-container button:hover {
    background: #0056b3;
  }

  /* Map Container */
  .map-container {
    margin-top: 20px;
    width: 100%;
    height: 300px;
    background: #f0f0f0;
    border-radius: 10px;
    overflow: hidden;
  }

  .map-container iframe {
    width: 100%;
    height: 100%;
    border: none;
  }

  /* Layout */
  .form-layout {
    display: flex;
    gap: 20px;
  }

  .form-layout .form-container {
    flex: 1;
  }

  .form-layout .map-container {
    flex: 1;
  }
</style>
</head>
<body>
<!-- top-header -->
<div class="top-header">
  <?php include('includes/header.php');?>
  <div class="banner-1 ">
    <div class="container">
      <h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">UTRS-User Travel Recommendation System</h1>
    </div>
  </div>
</div>
<!--- /banner-1 ---->
<!--- privacy ---->
<div class="privacy">
  <div class="container">
    <h3 class="wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">Enquiry Form</h3>
    <div class="form-layout">
      <div class="form-container">
        <form name="enquiry" method="post">
         
          <p>
            <b>Full name</b>  
            <input type="text" name="fname" class="form-control" id="fname" placeholder="Full Name" required="">
          </p> 
          <p>
            <b>Email</b>  
            <input type="email" name="email" class="form-control" id="email" placeholder="Valid Email id" required="">
          </p> 
          <p>
            <b>Mobile No</b>  
            <input type="text" name="mobileno" class="form-control" id="mobileno" maxlength="10" placeholder="10 Digit mobile No" required="">
          </p> 
          <p>
            <b>Subject</b>  
            <input type="text" name="subject" class="form-control" id="subject" placeholder="Subject" required="">
          </p> 
          <p>
            <b>Description</b>  
            <textarea name="description" class="form-control" rows="6" cols="50" id="description" placeholder="Description" required=""></textarea> 
          </p> 
          <p>
            <button type="submit" name="submit1" class="btn-primary btn">Submit</button>
          </p>
        </form>
      </div>
      <div class="map-container">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3503.853372762634!2d77.2093153150818!3d28.57208298243971!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce2a99b6f9fa7%3A0x83a25e55f0af1c82!2sIndia%20Gate!5e0!3m2!1sen!2sin!4v1632912345678!5m2!1sen!2sin" allowfullscreen="" loading="lazy"></iframe>
      </div>
    </div>
  </div>
</div>
<!--- /privacy ---->
<!--- footer-top ---->
<!--- /footer-top ---->
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>