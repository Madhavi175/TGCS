<?PHP
session_start();
error_reporting(0);
include('includes/config.php');

// Initialize variables
$error = '';
$msg = '';

if (isset($_POST['submit1'])) {
    $fname = $_POST['fname'];
    $email = $_POST['email'];
    $mobile = $_POST['mobileno'];
    $subject = $_POST['subject'];
    $description = $_POST['description'];

    // Basic validation
    if (empty($fname)) {
        $error = "Full Name is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    } elseif (!preg_match('/^[0-9]{10}$/', $mobile)) {
        $error = "Mobile number must be 10 digits";
    } else {
        $sql = "INSERT INTO tblenquiry (FullName, EmailId, MobileNumber, Subject, Description) 
                VALUES (:fname, :email, :mobile, :subject, :description)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':fname', $fname, PDO::PARAM_STR);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->bindParam(':mobile', $mobile, PDO::PARAM_STR);
        $query->bindParam(':subject', $subject, PDO::PARAM_STR);
        $query->bindParam(':description', $description, PDO::PARAM_STR);
        
        if ($query->execute()) {
            // Redirect to avoid form resubmission
            header("Location: {$_SERVER['PHP_SELF']}?success=1");
            exit;
        } else {
            $error = "Something went wrong. Please try again";
        }
    }
}

// Check if success message should be displayed
if (isset($_GET['success'])) {
    $msg = "Enquiry Successfully Submitted";
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>UTRS | Contact Us</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
    new WOW().init();
</script>
<style>
  /* Base Styles */
  body {
    font-family: 'Roboto', sans-serif;
    background: linear-gradient(135deg, #0A1828, #112A46, #00A8E8);
    color: #fff;
    margin: 0;
    padding: 0;
  }

  /* Error and Success Messages */
  .errorWrap {
    padding: 15px;
    margin: 0 0 20px 0;
    background: rgba(255, 235, 238, 0.85);
    border-left: 5px solid #f44336;
    color: #d32f2f;
    border-radius: 4px;
    backdrop-filter: blur(5px);
  }
  
  .succWrap {
    padding: 15px;
    margin: 0 0 20px 0;
    background: rgba(232, 245, 233, 0.85);
    border-left: 5px solid #4caf50;
    color: #2e7d32;
    border-radius: 4px;
    backdrop-filter: blur(5px);
  }

  /* Contact Section */
  .contact-section {
    padding: 60px 0;
    margin-top: 60px;
  }
  
  .section-title {
    text-align: center;
    margin-bottom: 50px;
  }
  
  .section-title h2 {
    font-size: 36px;
    color: #fff;
    margin-bottom: 15px;
    position: relative;
    display: inline-block;
    text-shadow: 0 2px 4px rgba(0,0,0,0.2);
  }
  
  .section-title h2:after {
    content: '';
    position: absolute;
    width: 60px;
    height: 3px;
    background: #00A8E8;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
  }
  
  .section-title p {
    color: rgba(255,255,255,0.8);
    font-size: 18px;
  }

  /* Form Container */
  .form-container {
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 15px;
  }

  /* Contact Form */
  .contact-form {
    flex: 1;
    min-width: 300px;
    height: 800px;
    background: rgba(255, 255, 255, 0.1);
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
  }
  
  .contact-form h3 {
    color: #fff;
    font-size: 24px;
    margin-bottom: 25px;
    text-align: center;
  }
  
  .form-group {
    margin-bottom: 25px;
  }
  
  .form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: rgba(255,255,255,0.9);
  }
  
  .form-control {
    width: 100%;
    padding: 14px 18px;
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 6px;
    font-size: 16px;
    transition: all 0.3s ease;
    color: #fff;
  }
  
  .form-control::placeholder {
    color: rgba(255,255,255,0.5);
  }
  
  .form-control:focus {
    background: rgba(255, 255, 255, 0.15);
    border-color: #00A8E8;
    box-shadow: 0 0 0 3px rgba(0, 168, 232, 0.2);
    outline: none;
  }
  
  textarea.form-control {
    min-height: 180px;
    resize: vertical;
  }
  
  .btn-primary {
    background: linear-gradient(135deg, #00A8E8, #0077B6);
    color: #fff;
    border: none;
    padding: 14px 30px;
    font-size: 16px;
    font-weight: 500;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.3s ease;
    width: 100%;
    letter-spacing: 0.5px;
    text-transform: uppercase;
  }
  
  .btn-primary:hover {
    background: linear-gradient(135deg, #0077B6, #00A8E8);
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
  }

  /* Contact Info */
  .contact-info {
    flex: 1;
    min-width: 300px;
  }
  
  .info-box {
    background: rgba(255, 255, 255, 0.1);
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    margin-bottom: 30px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
  }
  
  .info-box h3 {
    font-size: 24px;
    margin-bottom: 25px;
    color: #fff;
    text-align: center;
  }
  
  .info-item {
    display: flex;
    align-items: flex-start;
    margin-bottom: 20px;
  }
  
  .info-icon {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #00A8E8, #0077B6);
    color: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    margin-right: 15px;
    flex-shrink: 0;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  }
  
  .info-text h4 {
    font-size: 18px;
    margin-bottom: 5px;
    color: #fff;
  }
  
  .info-text p {
    color: rgba(255,255,255,0.7);
    margin: 0;
  }
  
  /* Map Container */
  .map-container {
    height: 400px;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.2);
  }
  
  .map-container iframe {
    width: 100%;
    height: 100%;
    border: none;
  }
  
  /* Responsive */
  @media (max-width: 768px) {
    .form-container {
      flex-direction: column;
    }
    
    .contact-form, .contact-info {
      width: 100%;
    }
    
    .section-title h2 {
      font-size: 28px;
    }
  }
</style>
</style>
</head>
<body style="background: linear-gradient(135deg, #0A1828, #112A46, #00A8E8);">
<?php include('includes/header.php');?>

<!-- Contact Section -->
<section class="contact-section">
  <div class="container">
    <div class="section-title">
      <h2>Contact Us</h2>
      <p>Have questions or feedback? We'd love to hear from you!</p>
    </div>
    
    <div class="form-container">
      <div class="contact-form">
        <h3>Send us a message</h3>
        <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div><?php }?>
        
        <form name="enquiry" method="post">
          <div class="form-group">
            <label for="fname">Full Name</label>
            <input type="text" name="fname" class="form-control" id="fname" placeholder="Your full name" required value="<?php echo isset($_POST['fname']) ? htmlentities($_POST['fname']) : ''; ?>">
          </div>
          
          <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" name="email" class="form-control" id="email" placeholder="Your email address" required value="<?php echo isset($_POST['email']) ? htmlentities($_POST['email']) : ''; ?>">
          </div>
          
          <div class="form-group">
            <label for="mobileno">Mobile Number</label>
            <input type="text" name="mobileno" class="form-control" id="mobileno" maxlength="10" placeholder="10 digit mobile number" required value="<?php echo isset($_POST['mobileno']) ? htmlentities($_POST['mobileno']) : ''; ?>">
          </div>
          
          <div class="form-group">
            <label for="subject">Subject</label>
            <input type="text" name="subject" class="form-control" id="subject" placeholder="Subject of your message" required value="<?php echo isset($_POST['subject']) ? htmlentities($_POST['subject']) : ''; ?>">
          </div>
          
          <div class="form-group">
            <label for="description">Your Message</label>
            <textarea name="description" class="form-control" id="description" placeholder="Your message here..." required><?php echo isset($_POST['description']) ? htmlentities($_POST['description']) : ''; ?></textarea>
          </div>
          
          <button type="submit" name="submit1" class="btn-primary">Send Message</button>
        </form>
      </div>
      
      <div class="contact-info">
        <div class="info-box">
          <h3>Contact Information</h3>
          
          <div class="info-item">
            <div class="info-icon">
              <i class="fa fa-map-marker"></i>
            </div>
            <div class="info-text">
              <h4>Location</h4>
              <p>123 Tourism Street, Nagpur, Maharashtra, India</p>
            </div>
          </div>
          
          <div class="info-item">
            <div class="info-icon">
              <i class="fa fa-phone"></i>
            </div>
            <div class="info-text">
              <h4>Phone</h4>
              <p>+91 9876543210</p>
            </div>
          </div>
          
          <div class="info-item">
            <div class="info-icon">
              <i class="fa fa-envelope"></i>
            </div>
            <div class="info-text">
              <h4>Email</h4>
              <p>info@utrs.com</p>
            </div>
          </div>
          
          <div class="info-item">
            <div class="info-icon">
              <i class="fa fa-clock-o"></i>
            </div>
            <div class="info-text">
              <h4>Working Hours</h4>
              <p>Monday - Friday: 9AM to 6PM</p>
              <p>Saturday: 10AM to 4PM</p>
            </div>
          </div>
        </div>
        
        <div class="map-container">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d119065.0130118794!2d79.07251014999999!3d21.16108585!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd4c0a5a31faf13%3A0x19b37d06d0bb3e2b!2sNagpur%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1742203314902!5m2!1sen!2sin" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>            
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>            
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>