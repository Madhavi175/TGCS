<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0) {    
    header('location:index.php');
}
else {
    if(isset($_POST['submit'])) {
        $pname=$_POST['packagename'];
        $ptype=$_POST['packagetype'];    
        $plocation=$_POST['packagelocation'];
        $pprice=$_POST['packageprice'];    
        $pfeatures=$_POST['packagefeatures'];
        $pdetails=$_POST['packagedetails'];    
        $pimage=$_FILES["packageimage"]["name"];
        move_uploaded_file($_FILES["packageimage"]["tmp_name"],"pacakgeimages/".$_FILES["packageimage"]["name"]);
        
        $sql="INSERT INTO tbltourpackages(PackageName,PackageType,PackageLocation,PackagePrice,PackageFetures,PackageDetails,PackageImage) VALUES(:pname,:ptype,:plocation,:pprice,:pfeatures,:pdetails,:pimage)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':pname',$pname,PDO::PARAM_STR);
        $query->bindParam(':ptype',$ptype,PDO::PARAM_STR);
        $query->bindParam(':plocation',$plocation,PDO::PARAM_STR);
        $query->bindParam(':pprice',$pprice,PDO::PARAM_STR);
        $query->bindParam(':pfeatures',$pfeatures,PDO::PARAM_STR);
        $query->bindParam(':pdetails',$pdetails,PDO::PARAM_STR);
        $query->bindParam(':pimage',$pimage,PDO::PARAM_STR);
        $query->execute();
        $lastInsertId = $dbh->lastInsertId();
        
        if($lastInsertId) {
            $msg="Package Created Successfully";
        } else {
            $error="Something went wrong. Please try again";
        }
    }
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TGCS | Admin Package Creation</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<style>
:root {
  --primary: #000000;
  --secondary: #ffffff;
  --accent: #f5f5f5;
  --text: #333333;
  --light-gray: #e0e0e0;
  --dark-gray: #757575;
  --error: #d32f2f;
  --success: #388e3c;
  --mint: #4cbb9a;
}

body {
  font-family: 'Roboto', sans-serif;
  background-color: var(--secondary);
  color: var(--text);
  line-height: 1.6;
  margin: 0;
  padding: 0;
}

.page-container {
  display: flex;
  min-height: 100vh;
  position: relative;
}

.left-content {
  flex: 1;
  padding: 30px;
  background-color: var(--accent);
  margin-left: 250px; /* Adjust based on your sidebar width */
  min-height: calc(100vh - 60px);
  display: flex;
  flex-direction: column;
}

.header {
  background-color: var(--secondary);
  padding: 15px 0;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.grid-form {
  background-color: var(--secondary);
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
  padding: 30px;
  margin: 20px auto;
  max-width: 800px;
  width: 100%;
  flex-grow: 1;
}

.grid-form1 h3 {
  color: var(--primary);
  margin-top: 0;
  margin-bottom: 15px;
  font-weight: 600;
  font-size: 28px;
  letter-spacing: 0.5px;
  position: relative;
  padding-bottom: 15px;
}

.grid-form1 h3::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 3px;
  background: var(--mint);
  border-radius: 3px;
}

.form-horizontal {
  width: 100%;
}

.form-group {
  margin-bottom: 25px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  font-weight: 500;
  color: var(--primary);
}

.form-control {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid var(--light-gray);
  border-radius: 4px;
  font-size: 14px;
  transition: all 0.3s;
  background-color: var(--secondary);
  color: var(--text);
}

.form-control:focus {
  border-color: var(--primary);
  outline: none;
  box-shadow: 0 0 0 2px rgba(0,0,0,0.05);
}

textarea.form-control {
  min-height: 150px;
  resize: vertical;
}

input[type="file"] {
  padding: 10px 0;
  width: 100%;
}

.btn {
  display: inline-block;
  padding: 12px 24px;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  text-align: center;
}

.btn-primary {
  background-color: var(--primary);
  color: var(--secondary);
}

.btn-primary:hover {
  background-color: #333333;
  transform: translateY(-2px);
}

.btn-inverse {
  background-color: var(--secondary);
  color: var(--primary);
  border: 1px solid var(--light-gray);
  margin-left: 10px;
}

.btn-inverse:hover {
  background-color: var(--accent);
}

.errorWrap {
  padding: 15px;
  margin: 0 0 25px 0;
  background-color: #ffebee;
  border-left: 4px solid var(--error);
  color: var(--error);
  border-radius: 4px;
}

.succWrap {
  padding: 15px;
  margin: 0 0 25px 0;
  background-color: #e8f5e9;
  border-left: 4px solid var(--success);
  color: var(--success);
  border-radius: 4px;
}

.button-group {
  margin-top: 30px;
  text-align: center;
}

/* Footer Styles */
.footer {
  background-color: var(--secondary);
  padding: 20px 0;
  text-align: center;
  margin-top: auto;
  width: calc(100% - 250px); /* Adjust based on sidebar width */
  margin-left: 250px; /* Same as left-content margin */
  box-shadow: 0 -1px 3px rgba(0,0,0,0.1);
}

@media (max-width: 768px) {
  .left-content {
    padding: 20px;
    margin-left: 0;
    width: 100%;
  }
  
  .footer {
    width: 100%;
    margin-left: 0;
  }
  
  .grid-form {
    padding: 20px;
  }
  
  .btn-inverse {
    margin-left: 0;
    margin-top: 10px;
    width: 100%;
  }
  
  .button-group .btn {
    width: 100%;
    margin-bottom: 10px;
  }
  
  .button-group .btn + .btn {
    margin-left: 0;
  }
}
</style>
</head>
<body>
<div class="page-container">
  <?php include('includes/sidebarmenu.php');?>
  
  <div class="left-content">
    <div class="">
      <?php include('includes/header.php');?>
    </div>
    
    <div class="grid-form">
      <div class="grid-form1">
        <h3>CREATE PACKAGE</h3>
        <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($msg); ?> </div><?php }?>
        
        <form class="form-horizontal" name="package" method="post" enctype="multipart/form-data">
          <div class="form-group">
            <label for="packagename">Package Name</label>
            <input type="text" class="form-control" name="packagename" id="packagename" placeholder="Enter package name" required>
          </div>
          
          <div class="form-group">
            <label for="packagetype">Package Type</label>
            <input type="text" class="form-control" name="packagetype" id="packagetype" placeholder="e.g. Family Package, Couple Package" required>
          </div>
          
          <div class="form-group">
            <label for="packagelocation">Package Location</label>
            <input type="text" class="form-control" name="packagelocation" id="packagelocation" placeholder="Enter destination location" required>
          </div>
          
          <div class="form-group">
            <label for="packageprice">Package Price (USD)</label>
            <input type="text" class="form-control" name="packageprice" id="packageprice" placeholder="Enter price in USD" required>
          </div>
          
          <div class="form-group">
            <label for="packagefeatures">Package Features</label>
            <input type="text" class="form-control" name="packagefeatures" id="packagefeatures" placeholder="e.g. Free pickup/drop facility" required>
          </div>
          
          <div class="form-group">
            <label for="packagedetails">Package Details</label>
            <textarea class="form-control" rows="5" name="packagedetails" id="packagedetails" placeholder="Enter detailed description" required></textarea>
          </div>
          
          <div class="form-group">
            <label for="packageimage">Package Image</label>
            <input type="file" class="form-control" name="packageimage" id="packageimage" required>
            <small class="text-muted">Upload a high-quality image for the package</small>
          </div>
          
          <div class="button-group">
            <button type="submit" name="submit" class="btn btn-primary">Create Package</button>
            <button type="reset" class="btn btn-inverse">Reset Form</button>
          </div>
        </form>
      </div>
    </div>
    
    <div class="">
      <?php include('includes/footer.php');?>
    </div>
  </div>
</div>

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php } ?>