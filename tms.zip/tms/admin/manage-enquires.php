<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{    
header('location:index.php');
}
else{ 
    // code for mark as read
    if(isset($_REQUEST['eid']))
    {
        $eid=intval($_GET['eid']);
        $status=1;

        $sql = "UPDATE tblenquiry SET Status=:status WHERE id=:eid";
        $query = $dbh->prepare($sql);
        $query -> bindParam(':status',$status, PDO::PARAM_STR);
        $query-> bindParam(':eid',$eid, PDO::PARAM_STR);
        $query -> execute();

        $msg="Enquiry successfully read";
        header("Location: manage-enquires.php");
        exit();
    }
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TGCS | Admin manage Bookings</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
:root {
    --white: #FFFFFF;
    --black: #333333;
    --gray: #F5F5F5;
    --dark-gray: #E0E0E0;
    --primary: #333333;
    --secondary: #666666;
    --blue: #3498db;
    --green: #2ecc71;
    --red: #e74c3c;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f9f9f9;
    color: var(--black);
}

.page-container {
    display: flex;
    min-height: 100vh;
}

.left-content {
    flex: 1;
    margin-left: 250px;
    transition: margin-left 0.3s ease;
    padding: 20px;
}

.sidebar-collapsed .left-content {
    margin-left: 70px;
}

.mother-grid-inner {
    max-width: 1200px;
    margin: 0 auto;
    width: 100%;
}

/* Error/Success Messages */
.errorWrap {
    padding: 12px 15px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid var(--red);
    box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    border-radius: 4px;
    color: var(--black);
}

.succWrap {
    padding: 12px 15px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid var(--green);
    box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    border-radius: 4px;
    color: var(--black);
}

/* Breadcrumb */
.breadcrumb {
    background: var(--white);
    padding: 12px 15px;
    border-radius: 4px;
    margin-bottom: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.breadcrumb a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 500;
}

.breadcrumb i {
    margin: 0 8px;
    color: #aaa;
}

/* Table Styling */
.w3l-table-info {
    background: var(--white);
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 2px 15px rgba(0,0,0,0.05);
    margin: 20px 0;
    overflow-x: auto;
}

.w3l-table-info h2 {
    color: var(--black);
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: 600;
    border-bottom: 2px solid var(--primary);
    padding-bottom: 10px;
}

#table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: 0.9em;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 0 20px rgba(0,0,0,0.05);
}

#table thead tr {
    background-color: var(--primary);
    color: var(--white);
    text-align: left;
    font-weight: 600;
}

#table th {
    padding: 15px;
    text-transform: uppercase;
    font-size: 13px;
    letter-spacing: 0.5px;
}

#table td {
    padding: 12px 15px;
    border-bottom: 1px solid var(--dark-gray);
    vertical-align: middle;
    color: var(--secondary);
}

#table tbody tr:nth-of-type(even) {
    background-color: var(--gray);
}

#table tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.03);
}

/* Status Indicators */
.status-read {
    color: var(--green);
    font-weight: 500;
}

.status-pending {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 4px;
    background-color: var(--red);
    color: var(--white);
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s ease;
}

.status-pending:hover {
    background-color: #c0392b;
    transform: translateY(-2px);
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.3);
}

/* Responsive Adjustments */
@media screen and (max-width: 992px) {
    .left-content {
        margin-left: 220px;
        padding: 15px;
    }
    
    .sidebar-collapsed .left-content {
        margin-left: 60px;
    }
}

@media screen and (max-width: 768px) {
    .left-content {
        margin-left: 0;
        padding: 10px;
    }
    
    .sidebar-collapsed .left-content {
        margin-left: 0;
    }
    
    #table {
        display: block;
        overflow-x: auto;
    }
    
    .w3l-table-info {
        padding: 15px;
    }
    
    #table td, #table th {
        padding: 8px 10px;
    }
    
    .status-pending {
        padding: 4px 8px;
        font-size: 0.8em;
    }
}
</style>
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
   <div class="left-content">
       <div class="mother-grid-inner">
            <!--header start here-->
            <?php include('includes/header.php');?>
            <div class="clearfix"></div>    
            
            <!--heder end here-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a><i class="fa fa-angle-right"></i>Manage Enquiries</li>
            </ol>
            
            <div class="agile-grids">    
                <!-- tables -->
                <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
                
                <div class="agile-tables">
                    <div class="w3l-table-info">
                        <h2>Manage Enquiries</h2>
                        <table id="table">
                            <thead>
                                <tr>
                                    <th>Ticket id</th>
                                    <th>Name</th>
                                    <th>Mobile No./ Email</th>
                                    <th>Subject</th>
                                    <th>Description</th>
                                    <th>Posting date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $sql = "SELECT * from tblenquiry";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);

                                if($query->rowCount() > 0) {
                                    foreach($results as $result) {
                                ?>        
                                <tr>
                                    <td>#TCKT-<?php echo htmlentities($result->id);?></td>
                                    <td><?php echo htmlentities($result->FullName);?></td>
                                    <td>
                                        <?php echo htmlentities($result->MobileNumber);?> <br />
                                        <?php echo $result->EmailId;?>
                                    </td>
                                    <td><?php echo htmlentities($result->Subject);?></td>
                                    <td><?php echo htmlentities($result->Description);?></td>
                                    <td><?php echo htmlentities($result->PostingDate);?></td>
                                    <td>
                                        <?php if($result->Status==1) { ?>
                                            <span class="status-read">Read</span>
                                        <?php } else { ?>
                                            <a href="manage-enquires.php?eid=<?php echo htmlentities($result->id);?>" 
                                               onclick="return confirm('Do you really want to mark this as read?')" 
                                               class="status-pending">Pending</a>
                                        <?php } ?>
                                    </td>
                                </tr>
                                <?php } } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!--inner block start here-->
            <div class="inner-block"></div>
            <!--inner block end here-->
            
            <!--copy rights start here-->
            <?php include('includes/footer.php');?>
            <!--COPY rights end here-->
        </div>
    </div>
    <!--//content-inner-->
    
    <!--/sidebar-menu-->
    <?php include('includes/sidebarmenu.php');?>
    <div class="clearfix"></div>        
</div>

<script>
$(document).ready(function() {
    // Sticky header
    var navoffeset = $(".header-main").offset().top;
    $(window).scroll(function(){
        var scrollpos = $(window).scrollTop(); 
        if(scrollpos >= navoffeset) {
            $(".header-main").addClass("fixed");
        } else {
            $(".header-main").removeClass("fixed");
        }
    });
    
    // Sidebar toggle
    var toggle = true;
    $(".sidebar-icon").click(function() {                
        if (toggle) {
            $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
            $("#menu span").css({"position":"absolute"});
        } else {
            $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
            setTimeout(function() {
                $("#menu span").css({"position":"relative"});
            }, 400);
        }
        toggle = !toggle;
    });
});
</script>

</body>
</html>
<?php } ?>