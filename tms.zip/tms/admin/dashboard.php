<?php
session_start();
if (!isset($_SESSION['alogin'])) {
    header("Location: index.php");
    exit();
}
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TGCS | Admin Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
/* Base Styles */
:root {
    --navy: #0a192f;
    --dark-blue: #172a45;
    --accent: #64ffda;
    --white: #ffffff;
    --light-gray: #ccd6f6;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: white;
    margin: 0;
    padding: 0;
    color: var(--light-gray);
}

.page-container {
    display: flex;
    min-height: 100vh;
}

.left-content {
    flex: 1;
    margin-left: 250px;
    transition: margin 0.3s ease;
    padding: 20px;
}

/* Dashboard Grid Layout */
.dashboard-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 25px;
    padding: 20px;
}

/* Card Design */
.dashboard-card {
    background: var(--dark-blue);
    border-radius: 8px;
    padding: 25px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.3);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    border: 1px solid rgba(100, 255, 218, 0.1);
}

.dashboard-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 15px rgba(10, 25, 47, 0.5);
    border-color: var(--accent);
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.card-icon {
    font-size: 32px;
    color: var(--accent);
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(100, 255, 218, 0.1);
}

.card-content h3 {
    margin: 0;
    font-size: 1.4rem;
    color: var(--white);
    font-weight: 500;
    letter-spacing: 0.5px;
}

.card-content .count {
    font-size: 2.4rem;
    font-weight: 600;
    color: var(--accent);
    margin: 10px 0;
}

.manage-link {
    display: block;
    text-align: right;
    color: var(--accent);
    text-decoration: none;
    font-weight: 500;
    margin-top: 15px;
    transition: all 0.3s ease;
    position: relative;
}

.manage-link:hover {
    color: var(--white);
}

/* Quick Actions */
.quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 25px;
    padding: 20px;
    background: #2F4F4F;
    border-radius: 8px;
    margin: 20px;
    border: 1px solid rgba(100, 255, 218, 0.1);
}

.action-card {
    background: var(--dark-blue);
    padding: 25px;
    border-radius: 8px;
    text-align: center;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border: 1px solid rgba(100, 255, 218, 0.1);
}

.action-card:hover {
    border-color: var(--accent);
    transform: translateY(-3px);
    background: var(--navy);
}

.action-card i {
    font-size: 32px;
    color: var(--accent);
    margin-bottom: 15px;
    transition: color 0.3s ease;
}

.action-card h4 {
    margin: 10px 0;
    color: var(--white);
    font-weight: 500;
}

.btn-primary {
    background: transparent;
    color: var(--accent);
    border: 1px solid var(--accent);
    padding: 10px 25px;
    border-radius: 4px;
    font-weight: 500;
    transition: all 0.3s ease;
    margin-top: 15px;
    display: inline-block;
}

.btn-primary:hover {
    background: rgba(100, 255, 218, 0.1);
    color: var(--accent);
    transform: translateY(-2px);
}

/* Responsive Design */
@media (max-width: 768px) {
    .left-content {
        margin-left: 0;
        padding: 15px;
    }
    
    .dashboard-grid {
        grid-template-columns: 1fr;
    }
    
    .card-content .count {
        font-size: 2rem;
    }
}

/* Animated Line Effect */
@keyframes movingLine {
    0% { background-position: 0 0; }
    100% { background-position: 100% 100%; }
}

.dashboard-card {
    position: relative;
    overflow: visible; /* Changed from hidden */
    padding-left: 35px; /* Add space for the line */
    border-left: none; /* Remove existing border */
}

.dashboard-card::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: 8px;
    height: 100%;
    background: linear-gradient(
        45deg,
        #2F4F4F 25%,
        #3B5F5F 25%,
        #3B5F5F 50%,
        #2F4F4F 50%,
        #2F4F4F 75%,
        #3B5F5F 75%
    );
    background-size: 200% 200%;
    animation: movingLine 2s linear infinite;
    border-radius: 8px 0 0 8px;
}

/* Adjust card content positioning */
.card-header,
.manage-link {
    position: relative;
    z-index: 1;
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="page-container">
    <?php include('includes/sidebarmenu.php'); ?>
    
    <div class="left-content">
        <?php include('includes/header.php'); ?>
        
        <div class="dashboard-grid">
            <!-- Users Card -->
            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-content">
                        <h3>Total Users</h3>
                        <div class="count"><?php echo getCount('tblusers', 'id'); ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <a href="manage-users.php" class="manage-link">Manage Users →</a>
            </div>

            <!-- Bookings Card -->
            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-content">
                        <h3>Total Bookings</h3>
                        <div class="count"><?php echo getCount('tblbooking', 'BookingId'); ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                </div>
                <a href="manage-bookings.php" class="manage-link">Manage Bookings →</a>
            </div>

            <!-- Enquiries Card -->
            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-content">
                        <h3>Total Enquiries</h3>
                        <div class="count"><?php echo getCount('tblenquiry', 'id'); ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                </div>
                <a href="manage-enquiries.php" class="manage-link">Manage Enquiries →</a>
            </div>

            <!-- Tour Packages Card -->
            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-content">
                        <h3>Tour Packages</h3>
                        <div class="count"><?php echo getCount('tbltourpackages', 'PackageId'); ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-suitcase"></i>
                    </div>
                </div>
                <a href="manage-packages.php" class="manage-link">Manage Packages →</a>
            </div>

            <!-- Issues Card -->
            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-content">
                        <h3>Issues Raised</h3>
                        <div class="count"><?php echo getCount('tblissues', 'id'); ?></div>
                    </div>
                    <div class="card-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
                <a href="manage-issues.php" class="manage-link">View Issues →</a>
            </div>
        </div>

        <!-- Quick Actions Section -->
        <div class="quick-actions">
            <div class="action-card">
                <i class="fas fa-plus-circle"></i>
                <h4>Create New Package</h4>
                <a href="create-package.php" class="btn btn-primary">Add New</a>
            </div>

            <div class="action-card">
                <i class="fas fa-chart-line"></i>
                <h4>View Reports</h4>
                <a href="generate-reports.php" class="btn btn-primary">Generate</a>
            </div>

            <div class="action-card">
                <i class="fas fa-user-cog"></i>
                <h4>Admin Settings</h4>
                <a href="admin-settings.php" class="btn btn-primary">Configure</a>
            </div>
        </div>

        <?php include('includes/footer.php'); ?>
    </div>
</div>

<?php
// Helper function to get counts
function getCount($table, $column) {
    global $dbh;
    $sql = "SELECT $column FROM $table";
    $query = $dbh->prepare($sql);
    $query->execute();
    return htmlentities($query->rowCount());
}
?>

<!-- Sidebar -->
<?php include('includes/sidebarmenu.php');?>

<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
    if (toggle) {
        $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
        $("#menu span").css({"position":"absolute"});
    } else {
        $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
        setTimeout(function() {
            $("#menu span").css({"position":"relative"});
        }, 400);
    }
    toggle = !toggle;
});
</script>

<!-- JavaScript Libraries -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>

<script>
$(document).ready(function() {
    // Initialize Morris Chart
    graphArea2 = Morris.Area({
        element: 'hero-area',
        padding: 10,
        behaveLikeLine: true,
        gridEnabled: false,
        gridLineColor: '#dddddd',
        axes: true,
        resize: true,
        smooth:true,
        pointSize: 0,
        lineWidth: 0,
        fillOpacity:0.85,
        data: [
            {period: '2023 Q1', bookings: 2668, enquiries: 2649},
            {period: '2023 Q2', bookings: 15780, enquiries: 12051},
            {period: '2023 Q3', bookings: 12920, enquiries: 9910},
            {period: '2023 Q4', bookings: 8770, enquiries: 6695},
            {period: '2024 Q1', bookings: 10820, enquiries: 12300}
        ],
        lineColors:['#ff6b35','#333'],
        xkey: 'period',
        ykeys: ['bookings', 'enquiries'],
        labels: ['Bookings', 'Enquiries'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });
});
</script>
</body>
</html>