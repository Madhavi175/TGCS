<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
// Code for change password	
if(isset($_POST['submit']))
	{
$password=md5($_POST['password']);
$newpassword=md5($_POST['newpassword']);
$username=$_SESSION['alogin'];
	$sql ="SELECT Password FROM admin WHERE UserName=:username and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':username', $username, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
$con="update admin set Password=:newpassword where UserName=:username";
$chngpwd1 = $dbh->prepare($con);
$chngpwd1-> bindParam(':username', $username, PDO::PARAM_STR);
$chngpwd1-> bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
$chngpwd1->execute();
$msg="Your Password succesfully changed";
}
else {
$error="Your current password is wrong";	
}
}
?>

<!DOCTYPE HTML>
<html>
<head>
<title>TGCS | Admin Change Password</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap 4 CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    body {
        background-color: #f8f9fa;
    }
    
    .wrapper {
        display: flex;
        min-height: 100vh;
    }
    
    #sidebar {
        min-width: 250px;
        max-width: 250px;
        background: #2c3e50;
        color: #fff;
        transition: all 0.3s;
        height: 100vh;
        position: fixed;
    }
    
    #sidebar .sidebar-header {
        padding: 20px;
        background: #1a252f;
    }
    
    #sidebar ul.components {
        padding: 20px 0;
    }
    
    .main-content {
        width: calc(100% - 250px);
        margin-left: 250px;
        padding: 20px;
        min-height: 100vh;
    }
    
    .card {
        border-radius: 5px;
        box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    
    .errorWrap, .succWrap {
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 4px;
    }
    
    .errorWrap {
        background: #f8d7da;
        border-left: 4px solid #dc3545;
        color: #721c24;
    }
    
    .succWrap {
        background: #d4edda;
        border-left: 4px solid #28a745;
        color: #155724;
    }
    
    .input-group-text {
        background: #e9ecef;
        border-radius: 0.25rem 0 0 0.25rem;
    }
</style>
</head>
<body>

<div class="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <?php include('includes/sidebarmenu.php'); ?>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <?php include('includes/header.php'); ?>
        
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Change Password</li>
            </ol>
        </nav>

        <!-- Form Section -->
        <div class="card">
            <div class="card-body">
                <?php if($error){ ?>
                    <div class="errorWrap"><?php echo htmlentities($error); ?></div>
                <?php } else if($msg){ ?>
                    <div class="succWrap"><?php echo htmlentities($msg); ?></div>
                <?php } ?>

                <h4 class="card-title mb-4">Change Password</h4>
                
                <form name="chngpwd" method="post" onSubmit="return valid();">
                    <!-- Current Password -->
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Current Password</label>
                        <div class="col-md-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-key"></i>
                                    </span>
                                </div>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <!-- New Password -->
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">New Password</label>
                        <div class="col-md-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-lock"></i>
                                    </span>
                                </div>
                                <input type="password" class="form-control" name="newpassword" required>
                            </div>
                        </div>
                    </div>

                    <!-- Confirm Password -->
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Confirm Password</label>
                        <div class="col-md-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-lock"></i>
                                    </span>
                                </div>
                                <input type="password" class="form-control" name="confirmpassword" required>
                            </div>
                        </div>
                    </div>

                    <!-- Buttons -->
                    <div class="form-group row">
                        <div class="col-md-9 offset-md-3">
                            <button type="submit" name="submit" class="btn btn-primary mr-2">Submit</button>
                            <button type="reset" class="btn btn-secondary">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Footer -->
        <?php include('includes/footer.php'); ?>
    </div>
</div>

<!-- Required Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    // Enable sidebar toggle
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
        });
    });
</script>

</body>
</html>
<?php } ?>
