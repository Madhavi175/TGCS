<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Color Variables */
        :root {
            --dark-blue: #0a192f;
            --navy-blue: #172a45;
            --light-blue: #64ffda;
            --white: #ffffff;
            --off-white: #ccd6f6;
            --shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        /* Body padding to account for fixed header */
        body {
            margin: 0;
            padding-top: 70px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Header Main Container - Fixed Position */
        .header-main {
            background: var(--dark-blue);
            padding: 0 30px;
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: var(--shadow);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            border-bottom: 1px solid rgba(100, 255, 218, 0.2);
        }

        /* Logo Styles - Centered */
        .logo-w3-agile {
            position: absolute;
            left: 10%;
            transform: translateX(-50%);
            text-align: center;
        }

        .logo-w3-agile h3 {
            margin: 0;
            padding: 0;
        }

        .logo-w3-agile h3 a {
            color: var(--light-blue);
            text-decoration: none;
            font-size: 22px;
            font-weight: 700;
            letter-spacing: 1px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            position: relative;
        }

        .logo-w3-agile h3 a:hover {
            color: var(--white);
        }

        .logo-w3-agile h3 a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background: var(--light-blue);
            transition: width 0.3s ease;
        }

        .logo-w3-agile h3 a:hover::after {
            width: 80%;
        }

        /* Profile Dropdown */
        .profile-container {
            position: relative;
            margin-left: auto;
        }

        .profile-btn {
            display: flex;
            align-items: center;
            background: rgba(100, 255, 218, 0.1);
            border: none;
            border-radius: 30px;
            padding: 8px 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .profile-btn:hover {
            background: rgba(100, 255, 218, 0.2);
            transform: translateY(-2px);
        }

        .profile-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(100, 255, 218, 0.5);
            margin-right: 10px;
            transition: all 0.3s ease;
        }

        .profile-btn:hover .profile-img {
            border-color: var(--light-blue);
            transform: scale(1.05);
        }

        .profile-text {
            text-align: left;
        }

        .profile-text .welcome {
            margin: 0;
            color: rgba(204, 214, 246, 0.8);
            font-size: 12px;
            text-transform: uppercase;
        }

        .profile-text .username {
            color: var(--off-white);
            font-size: 14px;
            font-weight: 600;
            display: block;
            margin-top: 2px;
        }

        /* Dropdown Menu */
        .profile-dropdown {
            position: absolute;
            right: 0;
            top: calc(100% + 10px);
            background: var(--navy-blue);
            border: 1px solid rgba(100, 255, 218, 0.1);
            border-radius: 8px;
            padding: 10px 0;
            min-width: 200px;
            box-shadow: var(--shadow);
            display: none;
            z-index: 1001;
            border-top: 3px solid var(--light-blue);
        }

        .profile-dropdown.show {
            display: block;
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .profile-dropdown::before {
            content: '';
            position: absolute;
            top: -10px;
            right: 20px;
            width: 0;
            height: 0;
            border-left: 10px solid transparent;
            border-right: 10px solid transparent;
            border-bottom: 10px solid var(--navy-blue);
        }

        .dropdown-item {
            color: var(--off-white);
            padding: 10px 20px;
            display: block;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .dropdown-item:hover {
            color: var(--light-blue);
            background: rgba(100, 255, 218, 0.1);
            padding-left: 25px;
        }

        .dropdown-item i {
            margin-right: 10px;
            color: var(--light-blue);
            width: 18px;
            text-align: center;
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding-top: 60px;
            }
            
            .header-main {
                padding: 0 15px;
                height: 60px;
            }
            
            .logo-w3-agile {
                position: static;
                transform: none;
                text-align: left;
                flex: 1;
            }
            
            .logo-w3-agile h3 a {
                font-size: 18px;
            }
            
            .profile-text {
                display: none;
            }
            
            .profile-btn {
                padding: 8px;
            }
            
            .profile-dropdown {
                min-width: 160px;
            }
        }
    </style>
</head>
<body>
    <div class="header-main">
        <div class="logo-w3-agile">
            <h3><a href="dashboard.php"><b>Admin Dashboard</b></a></h3>
        </div>
        
        <div class="profile-container">
            <button class="profile-btn" id="profileDropdownBtn">
                <img src="images/User-icon.png" alt="Profile" class="profile-img">
                <div class="profile-text">
                    <p class="welcome">Welcome</p>
                    <span class="username">Administrator</span>
                </div>
            </button>
            
            <div class="profile-dropdown" id="profileDropdown">
                <a href="change-password.php" class="dropdown-item"><i class="fas fa-lock"></i> Change Password</a>
                <a href="logout.php" class="dropdown-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <!-- Sample content to demonstrate fixed header -->
    <!-- <div style="height: 2000px; padding: 20px;">
        <h2>Page Content</h2>
        <p>Scroll down to see the header remains fixed at the top.</p>
    </div> -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dropdownBtn = document.getElementById('profileDropdownBtn');
            const dropdownMenu = document.getElementById('profileDropdown');
            
            // Toggle dropdown on button click
            dropdownBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                dropdownMenu.classList.toggle('show');
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function() {
                if (dropdownMenu.classList.contains('show')) {
                    dropdownMenu.classList.remove('show');
                }
            });
        });
    </script>
</body>
</html>