<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">    <style>
        /* Color Variables */
        :root {
            --dark-blue: #0a192f;
            --navy-blue: #172a45;
            --mint-white: #e6f9ff;
            --light-mint: #64ffda;
            --white: #ffffff;
            --shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        /* Sidebar Base Styles */
        .sidebar-menu {
            position: fixed;
            width: 260px;
            height:100vh;
            background: var(--dark-blue);
            box-shadow: 5px 0 25px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            overflow-y: auto;
            transition: all 0.3s ease;
            transform: translateX(0);
            border-right: 1px solid rgba(100, 255, 218, 0.2);
        }

        /* Logo Header */
        .logo1 {
            padding: 25px 20px;
            background: var(--navy-blue);
            text-align: center;
            border-bottom: 1px solid rgba(100, 255, 218, 0.2);
        }

        .sidebar-icon {
            color: var(--light-mint);
            font-size: 24px;
            display: inline-block;
            transition: all 0.3s ease;
            background: rgba(100, 255, 218, 0.1);
            padding: 10px;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            line-height: 25px;
            border: 1px solid rgba(100, 255, 218, 0.3);
        }
        /* Custom icon adjustments */
.fa-envelope-open-text {
    font-size: 14px !important;
    padding: 8px !important;
}

.fa-file-lines {
    font-size: 15px !important;
    padding: 7px !important;
}

        .sidebar-icon:hover {
            transform: rotate(90deg);
            background: rgba(100, 255, 218, 0.2);
            color: var(--white);
        }

        /* Menu Styles */
        .menu {
            padding: 15px 0;
        }

        .menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .menu ul li {
            position: relative;
        }

        .menu ul li a {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: var(--mint-white);
            text-decoration: none;
            font-size: 15px;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
            margin: 5px 10px;
            border-radius: 4px;
        }

       
        .menu ul li a:hover i,
.menu ul li a:focus i {
    background: rgba(100, 255, 218, 0.2);
    color: var(--white);
    transform: scale(1.1);
    box-shadow: 0 0 10px rgba(100, 255, 218, 0.2);
}

      
        .menu ul li a i {
    margin-right: 15px;
    color: var(--light-mint);
    width: 30px;
    height: 30px;
    text-align: center;
    font-size: 16px;
    background: rgba(100, 255, 218, 0.1);
    border-radius: 50%;
    padding: 7px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 1px solid rgba(100, 255, 218, 0.3);
    transition: all 0.3s ease;
}
        .menu ul li a .fa-angle-right {
            transition: all 0.3s ease;
            margin-left: auto;
            font-size: 16px;
            color: rgba(230, 249, 255, 0.5);
        }

        /* Active Menu Item */
        .menu ul li.active > a {
            background: linear-gradient(to right, rgba(100, 255, 218, 0.2), transparent);
            color: var(--white);
            border-left: 4px solid var(--light-mint);
        }

        
        .menu ul li.active > a i {
    background: var(--light-mint);
    color: var(--dark-blue);
    border-color: var(--light-mint);
}

        /* Dropdown Submenu */
        #menu-academico-sub {
            display: none;
            background: rgba(23, 42, 69, 0.5);
            padding-left: 0;
            animation: fadeIn 0.3s ease-out;
            border-left: 4px solid rgba(100, 255, 218, 0.5);
            margin-left: 30px;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        #menu-academico.active > a .fa-angle-right {
            transform: rotate(90deg);
            color: var(--light-mint);
        }

        #menu-academico.active #menu-academico-sub {
            display: block;
        }

        #menu-academico-sub li a {
            padding: 12px 25px 12px 45px;
            font-size: 14px;
            border-left: none;
            margin: 0;
            color: rgba(230, 249, 255, 0.7);
        }
        #menu-academico-sub li a i {
    width: 25px;
    height: 25px;
    font-size: 14px;
    padding: 5px;
    margin-right: 10px;
}


        #menu-academico-sub li a:hover {
            background: rgba(100, 255, 218, 0.05);
            color: var(--white);
        }

        #menu-academico-sub li a::before {
            content: "•";
            color: var(--light-mint);
            margin-right: 10px;
        }

        /* Divider */
        .divider {
            border-top: 1px solid rgba(100, 255, 218, 0.1);
            margin: 15px 25px;
        }

        /* Scrollbar Styling */
        .sidebar-menu::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-menu::-webkit-scrollbar-track {
            background: rgba(23, 42, 69, 0.3);
        }

        .sidebar-menu::-webkit-scrollbar-thumb {
            background: rgba(100, 255, 218, 0.5);
            border-radius: 10px;
        }

        .sidebar-menu::-webkit-scrollbar-thumb:hover {
            background: var(--light-mint);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar-menu {
                transform: translateX(-280px);
            }
            
            .sidebar-menu.active {
                transform: translateX(0);
            }
        }
    

/* Responsive adjustments */
@media (max-width: 768px) {
    .menu ul li a i {
        width: 28px;
        height: 28px;
        font-size: 15px;
        padding: 6px;
    }
}


    </style>
</head>
<body>
    <div class="sidebar-menu">
        <div class="divider"></div>
        <div class="menu">
            <ul id="menu">
                <li><a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span></a></li>
                
                <li id="menu-academico"><a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> Tour Packages</span> <span class="fa fa-angle-right" style="float: right"></span></a>
                    <ul id="menu-academico-sub">
                        <li id="menu-academico-avaliacoes"><a href="create-package.php">Create</a></li>
                        <li id="menu-academico-avaliacoes"><a href="manage-packages.php">Manage</a></li>
                    </ul>
                </li>
                
                <li><a href="manage-users.php"><i class="fa fa-users" aria-hidden="true"></i><span>Manage Users</span></a></li>
                
                <li><a href="manage-bookings.php"><i class="fa fa-list" aria-hidden="true"></i> <span>Manage Booking</span></a></li>
                <li><a href="manageissues.php"><i class="fa fa-table"></i> <span>Manage Issues</span></a></li>
               
<li><a href="manage-enquires.php"><i class="fa-solid fa-envelope-open-text" aria-hidden="true"></i> <span>Manage Enquiries</span></a></li>
<!-- <li><a href="manage-pages.php"><i class="fa-regular fa-file-lines" aria-hidden="true"></i> <span>Manage Pages</span></a></li> -->
</ul>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const menuItems = document.querySelectorAll('#menu-academico > a');
            
            menuItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    if (this.parentElement.querySelector('ul')) {
                        e.preventDefault();
                        this.parentElement.classList.toggle('active');
                        
                        // Close other open dropdowns
                        menuItems.forEach(otherItem => {
                            if (otherItem !== this && otherItem.parentElement.classList.contains('active')) {
                                otherItem.parentElement.classList.remove('active');
                            }
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>