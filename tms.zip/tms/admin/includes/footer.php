<div class="copyrights">
	 <p>© 2025 TGCS. All Rights Reserved |  <a href="#">TGCS</a> </p>
</div>	
