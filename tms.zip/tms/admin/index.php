
<?php
session_start();
include('includes/config.php');

if(isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // SQL injection prevention
    $username = htmlspecialchars(strip_tags($username));
    $password = htmlspecialchars(strip_tags($password));

    // Query to check admin credentials
    $sql = "SELECT * FROM admin WHERE UserName = :username AND Password = :password";
    $query = $dbh->prepare($sql);
    $query->bindParam(':username', $username, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->execute();

    if($query->rowCount() > 0) {
        $_SESSION['alogin'] = $username; // Set admin session
        header("Location: dashboard.php");
        exit();
    } else {
        echo "<script>alert('Invalid username or password');</script>";
    }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TGCS | Admin Sign in</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
/* Base Styles */
body {
    background: linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d);
    background-size: 400% 400%;
    animation: gradientBG 15s ease infinite;
    font-family: 'Montserrat', sans-serif;
    height: 100vh;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #333;
}

@keyframes gradientBG {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.main-wthree {
    width: 100%;
    max-width: 500px;
    animation: fadeIn 0.8s ease-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.container {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 10px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    padding: 40px;
    position: relative;
    overflow: hidden;
}

.container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 5px;
    height: 100%;
    background: linear-gradient(to bottom, #1a2a6c, #fdbb2d);
}

.sin-w3-agile h2 {
    text-align: center;
    color: #1a2a6c;
    font-weight: 700;
    margin-bottom: 30px;
    font-size: 28px;
    text-transform: uppercase;
    letter-spacing: 1px;
    position: relative;
    padding-bottom: 15px;
}

.sin-w3-agile h2::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 3px;
    background: linear-gradient(to right, #1a2a6c, #fdbb2d);
}

/* Form Styles */
.username, .password-agileits {
    margin-bottom: 25px;
    position: relative;
}

.username span, .password-agileits span {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
    font-size: 14px;
}

input.name, input.password {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
    transition: all 0.3s;
    box-sizing: border-box;
}

input.name:focus, input.password:focus {
    border-color: #1a2a6c;
    box-shadow: 0 0 0 3px rgba(26, 42, 108, 0.2);
    outline: none;
}

/* Button Styles */
.login-w3 {
    margin-top: 30px;
    text-align: center;
}

input.login {
    background: linear-gradient(to right, #1a2a6c, #b21f1f);
    color: white;
    border: none;
    padding: 14px 30px;
    font-size: 16px;
    font-weight: 600;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s;
    width: 100%;
    text-transform: uppercase;
    letter-spacing: 1px;
    box-shadow: 0 4px 15px rgba(26, 42, 108, 0.3);
}

input.login:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(26, 42, 108, 0.4);
    background: linear-gradient(to right, #b21f1f, #1a2a6c);
}

/* Back Link */
.back {
    text-align: center;
    margin-top: 25px;
}

.back a {
    color: #666;
    text-decoration: none;
    font-size: 14px;
    transition: color 0.3s;
    display: inline-block;
    position: relative;
}

.back a:hover {
    color: #1a2a6c;
}

.back a::after {
    content: '';
    position: absolute;
    width: 100%;
    height: 1px;
    bottom: 0;
    left: 0;
    background-color: #1a2a6c;
    transform: scaleX(0);
    transition: transform 0.3s;
}

.back a:hover::after {
    transform: scaleX(1);
}

/* Responsive */
@media (max-width: 600px) {
    .container {
        padding: 30px 20px;
        margin: 0 15px;
    }
    
    .sin-w3-agile h2 {
        font-size: 24px;
    }
}


.admin-badge {
    position: absolute;
    top: 15px;
    right: 15px;
    background: #1a2a6c;
    color: white;
    padding: 5px 10px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
}
</style>
</head>
<body>
    <div class="main-wthree">
        <div class="container">
            <div class="admin-badge">Admin</div>
            <div class="sin-w3-agile">
                <h2>Admin Portal</h2>
                <form method="post">
                    <div class="username">
                        <span class="username">Username:</span>
                        <input type="text" name="username" class="name" placeholder="Enter admin username" required>
                        <div class="clearfix"></div>
                    </div>
                    <div class="password-agileits">
                        <span class="username">Password:</span>
                        <input type="password" name="password" class="password" placeholder="Enter your password" required>
                        <div class="clearfix"></div>
                    </div>
                    
                    <div class="login-w3">
                        <input type="submit" class="login" name="login" value="Sign In">
                    </div>
                    <div class="clearfix"></div>
                </form>
                <div class="back">
                    <a href="../index.php">← Back to home</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Keep your existing scripts -->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script>
        // Add animation to inputs when focused
        $(document).ready(function() {
            $('input.name, input.password').on('focus', function() {
                $(this).parent().css('transform', 'translateY(-5px)');
            }).on('blur', function() {
                $(this).parent().css('transform', 'translateY(0)');
            });
            
            // Form submission animation
            $('form').on('submit', function() {
                $('.login').css('transform', 'scale(0.95)');
            });
        });
    </script>
</body>
</html>