<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0) {    
    header('location:index.php');
}
else { 
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TGCS | Admin Manage Packages</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
/* Layout Structure */
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background: #f5f5f5;
    overflow-x: hidden;
}

.page-container {
    display: flex;
    min-height: 100vh;
}

.left-content {
    flex: 1;
    margin-left: 280px; /* Increased left margin */
    padding: 20px;
    transition: all 0.3s ease;
}

.sidebar-collapsed .left-content {
    margin-left: 80px; /* Adjusted for collapsed sidebar */
}

.mother-grid-inner {
    max-width: 1200px;
    margin: 0 auto;
    width: 100%;
}

/* Table Styles */
.w3l-table-info {
    background: #fff;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 2px 15px rgba(0,0,0,0.05);
    margin: 20px 0;
}

#table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: 0.9em;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 0 20px rgba(0,0,0,0.05);
}

#table thead tr {
    background-color: #4ABDAC;
    color: #ffffff;
    text-align: left;
    font-weight: 600;
}

#table th,
#table td {
    padding: 15px 20px;
    border-bottom: 1px solid #f0f0f0;
    text-align: left;
}

#table tbody tr:nth-of-type(even) {
    background-color: #f8f9fa;
}

#table tbody tr:hover {
    background-color: #f1f1f1;
}

.btn {
    background-color: #4ABDAC;
    color: #ffffff;
    padding: 8px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-block;
    font-size: 0.9em;
}

.btn:hover {
    background-color: #378f80;
}

/* Responsive Adjustments */
@media screen and (max-width: 992px) {
    .left-content {
        margin-left: 240px;
        padding: 15px;
    }
    
    .sidebar-collapsed .left-content {
        margin-left: 70px;
    }
}

@media screen and (max-width: 768px) {
    .left-content {
        margin-left: 0;
        padding: 10px;
    }
    
    .sidebar-collapsed .left-content {
        margin-left: 0;
    }
    
    #table {
        display: block;
        overflow-x: auto;
    }
    
    .w3l-table-info {
        padding: 15px;
    }
}
/* Breadcrumb */
.breadcrumb {
    background: var(--white);
    padding: 12px 15px;
    border-radius: 4px;
    margin-bottom: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.breadcrumb a {
    color: var(--mint-dark);
    text-decoration: none;
}

.breadcrumb i {
    margin: 0 8px;
    color: #aaa;
}
</style>
</head>
<body>
<!-- Sidebar Menu -->
<?php include('includes/sidebarmenu.php');?>

<div class="page-container">
    <div class="left-content">
        <div class="mother-grid-inner">
            <!-- Header -->
            <?php include('includes/header.php');?>
            <div class="clearfix"></div>

            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a><i class="fa fa-angle-right"></i>Manage Packages</li>
            </ol>

            <!-- Main Content -->
            <div class="agile-grids">    
                <div class="agile-tables">
                    <div class="w3l-table-info">
                        <h2>Manage Packages</h2>
                        <table id="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Type</th>
                                    <th>Location</th>
                                    <th>Price</th>
                                    <th>Creation Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $sql = "SELECT * from TblTourPackages";
                                $query = $dbh->prepare($sql);
                                $query->execute();
                                $results = $query->fetchAll(PDO::FETCH_OBJ);
                                $cnt = 1;
                                if($query->rowCount() > 0) {
                                    foreach($results as $result) { 
                                ?>
                                <tr>
                                    <td><?php echo htmlentities($cnt);?></td>
                                    <td><?php echo htmlentities($result->PackageName);?></td>
                                    <td><?php echo htmlentities($result->PackageType);?></td>
                                    <td><?php echo htmlentities($result->PackageLocation);?></td>
                                    <td>$<?php echo htmlentities($result->PackagePrice);?></td>
                                    <td><?php echo htmlentities($result->Creationdate);?></td>
                                    <td>
                                        <a href="update-package.php?pid=<?php echo htmlentities($result->PackageId);?>">
                                            <button type="button" class="btn">View Details</button>
                                        </a>
                                    </td>
                                </tr>
                                <?php $cnt++; } } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <?php include('includes/footer.php');?>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Toggle sidebar
    $(".sidebar-icon").click(function() {                
        $("body").toggleClass("sidebar-collapsed");
    });

    // Sticky header
    var navoffset = $(".header-main").offset().top;
    $(window).scroll(function(){
        var scrollpos = $(window).scrollTop(); 
        if(scrollpos >= navoffset){
            $(".header-main").addClass("fixed");
        } else {
            $(".header-main").removeClass("fixed");
        }
    });
});
</script>
</body>
</html>
<?php } ?>