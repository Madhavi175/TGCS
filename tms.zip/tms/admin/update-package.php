<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
$pid=intval($_GET['pid']);	
if(isset($_POST['submit']))
{
$pname=$_POST['packagename'];
$ptype=$_POST['packagetype'];	
$plocation=$_POST['packagelocation'];
$pprice=$_POST['packageprice'];	
$pfeatures=$_POST['packagefeatures'];
$pdetails=$_POST['packagedetails'];	
$pimage=$_FILES["packageimage"]["name"];
$sql="update TblTourPackages set PackageName=:pname,PackageType=:ptype,PackageLocation=:plocation,PackagePrice=:pprice,PackageFetures=:pfeatures,PackageDetails=:pdetails where PackageId=:pid";
$query = $dbh->prepare($sql);
$query->bindParam(':pname',$pname,PDO::PARAM_STR);
$query->bindParam(':ptype',$ptype,PDO::PARAM_STR);
$query->bindParam(':plocation',$plocation,PDO::PARAM_STR);
$query->bindParam(':pprice',$pprice,PDO::PARAM_STR);
$query->bindParam(':pfeatures',$pfeatures,PDO::PARAM_STR);
$query->bindParam(':pdetails',$pdetails,PDO::PARAM_STR);
$query->bindParam(':pid',$pid,PDO::PARAM_STR);
$query->execute();
$msg="Package Updated Successfully";
}

	?>
<!DOCTYPE HTML>
<html>
<head>
<title>UTRS | Admin Package Update</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
:root {
    --mint: #4DB6AC;
    --black: #2C3E50;
    --white: #FFFFFF;
}

body {
    background-color: var(--white);
    color: var(--black);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 20px;
}

.form-container {
    max-width: 800px;
    margin: 30px auto;
    padding: 30px;
    background: var(--white);
    border-radius: 8px;
    box-shadow: 0 2px 15px rgba(0,0,0,0.1);
}

.form-title {
    color: var(--black);
    font-size: 24px;
    margin-bottom: 30px;
    padding-bottom: 15px;
    border-bottom: 2px solid var(--mint);
}

.form-group {
    margin-bottom: 25px;
}

.form-label {
    display: block;
    font-weight: 600;
    margin-bottom: 8px;
    color: var(--black);
}

.form-input {
    width: 100%;
    padding: 12px 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 16px;
    transition: all 0.3s ease;
}

.form-input:focus {
    border-color: var(--mint);
    box-shadow: 0 0 0 3px rgba(77, 182, 172, 0.1);
    outline: none;
}

textarea.form-input {
    min-height: 150px;
    resize: vertical;
}

.btn-primary {
    background: var(--mint);
    color: var(--white);
    border: none;
    padding: 12px 30px;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.3s ease;
    width: 100%;
}

.btn-primary:hover {
    background: #3A928A;
    transform: translateY(-2px);
}

.alert {
    padding: 15px;
    margin: 0 0 20px 0;
    border-radius: 4px;
}

.alert-error {
    background: #FFEBEE;
    border-left: 4px solid #D32F2F;
}

.alert-success {
    background: #E8F5E9;
    border-left: 4px solid var(--mint);
}

.image-preview {
    border: 2px solid var(--mint);
    border-radius: 4px;
    padding: 5px;
    margin-bottom: 15px;
    max-width: 200px;
}

.change-image-link {
    color: var(--mint);
    font-weight: 500;
    transition: all 0.3s ease;
}

.change-image-link:hover {
    color: #3A928A;
    text-decoration: none;
}

.update-date {
    color: #666;
    font-size: 0.9em;
}

@media (max-width: 768px) {
    .form-container {
        padding: 20px;
        margin: 20px;
    }
    
    .form-title {
        font-size: 20px;
    }
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="page-container">
    <?php include('includes/header.php'); ?>
    <?php include('includes/sidebarmenu.php');?>
    <div class="left-content">
        <div class="mother-grid-inner">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a><i class="fa fa-angle-right"></i> Update Package</li>
            </ol>

            <div class="form-container">
                <h3 class="form-title">Update Tour Package</h3>
                
                <?php if(isset($error)): ?>
                    <div class="alert alert-error"><?php echo htmlentities($error); ?></div>
                <?php elseif(isset($msg)): ?>
                    <div class="alert alert-success"><?php echo htmlentities($msg); ?></div>
                <?php endif; ?>

                <?php 
                $sql = "SELECT * from TblTourPackages where PackageId=:pid";
                $query = $dbh->prepare($sql);
                $query->bindParam(':pid', $pid, PDO::PARAM_STR);
                $query->execute();
                $results = $query->fetchAll(PDO::FETCH_OBJ);
                if($query->rowCount() > 0) {
                    foreach($results as $result) { 
                ?>
                
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="form-label">Package Name</label>
                        <input type="text" class="form-input" name="packagename" value="<?php echo htmlentities($result->PackageName); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Package Type</label>
                        <input type="text" class="form-input" name="packagetype" value="<?php echo htmlentities($result->PackageType); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Location</label>
                        <input type="text" class="form-input" name="packagelocation" value="<?php echo htmlentities($result->PackageLocation); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Price (USD)</label>
                        <input type="text" class="form-input" name="packageprice" value="<?php echo htmlentities($result->PackagePrice); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Features</label>
                        <input type="text" class="form-input" name="packagefeatures" value="<?php echo htmlentities($result->PackageFetures); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Details</label>
                        <textarea class="form-input" name="packagedetails" required><?php echo htmlentities($result->PackageDetails); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Current Image</label>
                        <div>
                            <img src="pacakgeimages/<?php echo htmlentities($result->PackageImage); ?>" class="image-preview">
                            <a href="change-image.php?imgid=<?php echo htmlentities($result->PackageId); ?>" class="change-image-link">
                                <i class="fas fa-sync-alt"></i> Change Image
                            </a>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Last Updated</label>
                        <p class="update-date"><?php echo htmlentities($result->UpdationDate); ?></p>
                    </div>

                    <button type="submit" name="submit" class="btn-primary">Update Package</button>
                </form>
                <?php }} ?>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>


<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php } ?>
