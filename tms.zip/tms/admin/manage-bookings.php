<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{    
header('location:index.php');
}
else{ 
    // code for cancel
    if(isset($_REQUEST['bkid']))
    {
        $bid=intval($_GET['bkid']);
        $status=2;
        $cancelby='a';
        $sql = "UPDATE tblbooking SET status=:status,CancelledBy=:cancelby WHERE  BookingId=:bid";
        $query = $dbh->prepare($sql);
        $query -> bindParam(':status',$status, PDO::PARAM_STR);
        $query -> bindParam(':cancelby',$cancelby , PDO::PARAM_STR);
        $query-> bindParam(':bid',$bid, PDO::PARAM_STR);
        $query -> execute();

        $msg="Booking Cancelled successfully";
        // Redirect to prevent form resubmission
        header("Location: manage-bookings.php");
        exit();
    }

    if(isset($_REQUEST['bckid']))
    {
        $bcid=intval($_GET['bckid']);
        $status=1;
        $cancelby='a';
        $sql = "UPDATE tblbooking SET status=:status WHERE BookingId=:bcid";
        $query = $dbh->prepare($sql);
        $query -> bindParam(':status',$status, PDO::PARAM_STR);
        $query-> bindParam(':bcid',$bcid, PDO::PARAM_STR);
        $query -> execute();
        $msg="Booking Confirm successfully";
        // Redirect to prevent form resubmission
        header("Location: manage-bookings.php");
        exit();
    }
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TGCS| Admin manage Bookings</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
:root {
    --mint: #98FF98;
    --mint-dark: #79C7B2;
    --white: #FFFFFF;
    --black: #333333;
    --gray: #F5F5F5;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f9f9f9;
    color: var(--black);
}

.page-container {
    display: flex;
    min-height: 100vh;
}

.left-content {
    flex: 1;
    margin-left: 250px;
    transition: margin-left 0.3s ease;
    padding: 20px;
}

.sidebar-collapsed .left-content {
    margin-left: 70px;
}

.mother-grid-inner {
    max-width: 1200px;
    margin: 0 auto;
    width: 100%;
}

/* Error/Success Messages */
.errorWrap {
    padding: 12px 15px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    border-radius: 4px;
    color: var(--black);
}

.succWrap {
    padding: 12px 15px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    border-radius: 4px;
    color: var(--black);
}

/* Breadcrumb */
.breadcrumb {
    background: var(--white);
    padding: 12px 15px;
    border-radius: 4px;
    margin-bottom: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.breadcrumb a {
    color: var(--mint-dark);
    text-decoration: none;
}

.breadcrumb i {
    margin: 0 8px;
    color: #aaa;
}

/* Table Styling */
.w3l-table-info {
    background: var(--white);
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 2px 15px rgba(0,0,0,0.05);
    margin: 20px 0;
    overflow-x: auto;
}

.w3l-table-info h2 {
    color: var(--black);
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: 600;
    border-bottom: 2px solid var(--mint);
    padding-bottom: 10px;
}

#table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    font-size: 0.9em;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 0 20px rgba(0,0,0,0.05);
}

#table thead tr {
    background-color: var(--mint);
    color: var(--black);
    text-align: left;
    font-weight: 600;
}

#table th {
    padding: 15px;
    text-transform: uppercase;
    font-size: 13px;
    letter-spacing: 0.5px;
}

#table td {
    padding: 12px 15px;
    border-bottom: 1px solid #f0f0f0;
    vertical-align: middle;
}

#table tbody tr:nth-of-type(even) {
    background-color: var(--gray);
}

#table tbody tr:hover {
    background-color: rgba(152, 255, 152, 0.1);
}

/* Status Indicators */
.status-pending {
    color: #f39c12;
    font-weight: 500;
}

.status-confirmed {
    color: #2ecc71;
    font-weight: 500;
}

.status-cancelled {
    color: #e74c3c;
    font-weight: 500;
}

/* Action Buttons */
.action-links {
    display: flex;
    gap: 10px;
}

.action-btn {
    display: inline-block;
    padding: 8px 15px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: 500;
    font-size: 14px;
    transition: all 0.3s ease;
    text-align: center;
    min-width: 80px;
}

.cancel-btn {
    background-color: #e74c3c;
    color: white;
    border: 1px solid #c0392b;
}

.cancel-btn:hover {
    background-color: #c0392b;
    transform: translateY(-2px);
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.3);
}

.confirm-btn {
    background-color: #2ecc71;
    color: white;
    border: 1px solid #27ae60;
}

.confirm-btn:hover {
    background-color: #27ae60;
    transform: translateY(-2px);
    box-shadow: 0 2px 8px rgba(46, 204, 113, 0.3);
}

.cancelled-label {
    color: #7f8c8d;
    font-style: italic;
}

/* Responsive Adjustments */
@media screen and (max-width: 992px) {
    .left-content {
        margin-left: 220px;
        padding: 15px;
    }
    
    .sidebar-collapsed .left-content {
        margin-left: 60px;
    }
}

@media screen and (max-width: 768px) {
    .left-content {
        margin-left: 0;
        padding: 10px;
    }
    
    .sidebar-collapsed .left-content {
        margin-left: 0;
    }
    
    #table {
        display: block;
        overflow-x: auto;
    }
    
    .w3l-table-info {
        padding: 15px;
    }
    
    .action-links {
        flex-direction: column;
        gap: 5px;
    }
    
    .action-btn {
        width: 100%;
    }
}
</style>
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
   <div class="left-content">
       <div class="mother-grid-inner">
            <!--header start here-->
            <?php include('includes/header.php');?>
            <div class="clearfix"></div>    
            
            <!--heder end here-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a><i class="fa fa-angle-right"></i>Manage Bookings</li>
            </ol>
            
            <div class="agile-grids">    
                <!-- tables -->
                <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
                
                <div class="agile-tables">
                    <div class="w3l-table-info">
                        <h2>Manage Bookings</h2>
                        <table id="table">
                            <thead>
                                <tr>
                                    <th>Booking id</th>
                                    <th>Name</th>
                                    <th>Mobile No.</th>
                                    <th>Email Id</th>
                                    <th>Package</th>
                                    <th>From /To </th>
                                    <th>Comment </th>
                                    <th>Status </th>
                                    <th>Action </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $sql = "SELECT tblbooking.BookingId as bookid,tblusers.FullName as fname,tblusers.MobileNumber as mnumber,tblusers.EmailId as email,tbltourpackages.PackageName as pckname,tblbooking.PackageId as pid,tblbooking.FromDate as fdate,tblbooking.ToDate as tdate,tblbooking.Comment as comment,tblbooking.status as status,tblbooking.CancelledBy as cancelby,tblbooking.UpdationDate as upddate from tblusers join  tblbooking on  tblbooking.UserEmail=tblusers.EmailId join tbltourpackages on tbltourpackages.PackageId=tblbooking.PackageId";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0) {
                                    foreach($results as $result) {
                                ?>        
                                <tr>
                                    <td>#BK-<?php echo htmlentities($result->bookid);?></td>
                                    <td><?php echo htmlentities($result->fname);?></td>
                                    <td><?php echo htmlentities($result->mnumber);?></td>
                                    <td><?php echo htmlentities($result->email);?></td>
                                    <td><a href="update-package.php?pid=<?php echo htmlentities($result->pid);?>" style="color: var(--mint-dark); text-decoration: none;"><?php echo htmlentities($result->pckname);?></a></td>
                                    <td><?php echo htmlentities($result->fdate);?> To <?php echo htmlentities($result->tdate);?></td>
                                    <td><?php echo htmlentities($result->comment);?></td>
                                    <td>
                                        <?php 
                                        if($result->status==0) {
                                            echo '<span class="status-pending">Pending</span>';
                                        }
                                        if($result->status==1) {
                                            echo '<span class="status-confirmed">Confirmed</span>';
                                        }
                                        if($result->status==2 and $result->cancelby=='a') {
                                            echo '<span class="status-cancelled">Canceled by you at ' .$result->upddate.'</span>';
                                        } 
                                        if($result->status==2 and $result->cancelby=='u') {
                                            echo '<span class="status-cancelled">Canceled by User at ' .$result->upddate.'</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if($result->status==2) { ?>
                                            <span class="cancelled-label">Cancelled</span>
                                        <?php } else if($result->status==1) { ?>
                                            <span class="status-confirmed">Confirmed</span>
                                        <?php } else { ?>
                                            <div class="action-links">
                                                <a href="manage-bookings.php?bkid=<?php echo htmlentities($result->bookid);?>" 
                                                   class="action-btn cancel-btn" 
                                                   onclick="return confirm('Are you sure you want to cancel this booking?')">Cancel</a>
                                                <a href="manage-bookings.php?bckid=<?php echo htmlentities($result->bookid);?>" 
                                                   class="action-btn confirm-btn" 
                                                   onclick="return confirm('Are you sure you want to confirm this booking?')">Confirm</a>
                                            </div>
                                        <?php } ?>
                                    </td>
                                </tr>
                                <?php $cnt=$cnt+1; } } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!--inner block start here-->
            <div class="inner-block"></div>
            <!--inner block end here-->
            
            <!--copy rights start here-->
            <?php include('includes/footer.php');?>
            <!--COPY rights end here-->
        </div>
    </div>
    <!--//content-inner-->
    
    <!--/sidebar-menu-->
    <?php include('includes/sidebarmenu.php');?>
    <div class="clearfix"></div>        
</div>

<script>
$(document).ready(function() {
    // Sticky header
    var navoffeset = $(".header-main").offset().top;
    $(window).scroll(function(){
        var scrollpos = $(window).scrollTop(); 
        if(scrollpos >= navoffeset) {
            $(".header-main").addClass("fixed");
        } else {
            $(".header-main").removeClass("fixed");
        }
    });
    
    // Sidebar toggle
    var toggle = true;
    $(".sidebar-icon").click(function() {                
        if (toggle) {
            $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
            $("#menu span").css({"position":"absolute"});
        } else {
            $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
            setTimeout(function() {
                $("#menu span").css({"position":"relative"});
            }, 400);
        }
        toggle = !toggle;
    });
});
</script>

</body>
</html>
<?php } ?>