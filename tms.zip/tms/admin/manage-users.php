<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{	
    header('location:index.php');
}
else{ 
?>
<!DOCTYPE HTML>
<html>
<head>
<title>UTRS | Admin manage Users</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Add jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
    /* Color Scheme */
    :root {
        --mint: #98FF98;
        --mint-dark: #79C7B2;
        --white: #FFFFFF;
        --black: #333333;
        --gray: #F5F5F5;
    }
    
    /* Page Layout Fixes */
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        background: #f1f1f1;
        overflow-x: hidden;
    }
    
    .page-container {
        display: flex;
        min-height: 100vh;
        position: relative;
    }
    
    .left-content {
        flex: 1;
        margin-left: 250px; /* Increased from 220px to prevent overlap */
        transition: margin-left 0.3s ease;
        padding: 15px;
    }
    
    .sidebar-collapsed .left-content {
        margin-left: 70px; /* Increased from 50px */
    }
    
    .mother-grid-inner {
        padding: 15px;
        max-width: calc(100% - 30px); /* Prevent content from stretching too wide */
    }
    
    /* Table Styling */
    .w3l-table-info {
        background: var(--white);
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        margin: 20px 0;
        width: 100%;
        box-sizing: border-box;
    }
    
    .w3l-table-info h2 {
        color: var(--black);
        margin-bottom: 20px;
        font-size: 24px;
        font-weight: 600;
        border-bottom: 2px solid var(--mint);
        padding-bottom: 10px;
    }
    
    #table {
        width: 100%;
        border-collapse: collapse;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        table-layout: auto;
    }
    
    #table thead {
        background-color: var(--mint);
        color: var(--black);
    }
    
    #table th {
        padding: 12px 15px;
        text-align: left;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 14px;
        letter-spacing: 0.5px;
    }
    
    #table tbody tr {
        border-bottom: 1px solid #e0e0e0;
    }
    
    #table tbody tr:nth-child(even) {
        background-color: var(--gray);
    }
    
    #table tbody tr:hover {
        background-color: rgba(152, 255, 152, 0.1);
    }
    
    #table td {
        padding: 12px 15px;
        color: var(--black);
        font-size: 14px;
        word-break: break-word; /* Prevent long content from breaking layout */
    }
    
    /* Breadcrumb styling */
    .breadcrumb {
        background: var(--white);
        padding: 10px 15px;
        border-radius: 4px;
        margin-bottom: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        width: 100%;
        box-sizing: border-box;
    }
    
    .breadcrumb a {
        color: var(--mint-dark);
        text-decoration: none;
    }
    
    .breadcrumb i {
        margin: 0 8px;
        color: #aaa;
    }
    
    /* Responsive adjustments */
    @media (max-width: 992px) {
        .left-content {
            margin-left: 220px;
        }
        
        .sidebar-collapsed .left-content {
            margin-left: 60px;
        }
    }
    
    @media (max-width: 768px) {
        #table {
            display: block;
            overflow-x: auto;
        }
        
        .w3l-table-info {
            padding: 15px;
        }
        
        .left-content {
            margin-left: 0;
            padding: 10px;
        }
        
        .sidebar-collapsed .left-content {
            margin-left: 0;
        }
        
        .mother-grid-inner {
            padding: 10px;
        }
    }
</style>
</head> 
<body>
   <div class="page-container">
   <!-- Sidebar Menu -->
   <?php include('includes/sidebarmenu.php');?>
   
   <!--/content-inner-->
   <div class="left-content">
       <div class="mother-grid-inner">
            <!--header start here-->
            <?php include('includes/header.php');?>
            <div class="clearfix"></div>	
            
            <!--heder end here-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a><i class="fa fa-angle-right"></i>Manage Users</li>
            </ol>
            
            <div class="agile-grids">	
                <!-- tables -->
                <div class="agile-tables">
                    <div class="w3l-table-info">
                        <h2>Manage Users</h2>
                        <table id="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Mobile No.</th>
                                    <th>Email Id</th>
                                    <th>RegDate</th>
                                    <th>Updation Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $sql = "SELECT * from tblusers";
                                $query = $dbh->prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0) {
                                    foreach($results as $result) {				?>		
                                    <tr>
                                        <td><?php echo htmlentities($cnt);?></td>
                                        <td><?php echo htmlentities($result->FullName);?></td>
                                        <td><?php echo htmlentities($result->MobileNumber);?></td>
                                        <td><?php echo htmlentities($result->EmailId);?></td>
                                        <td><?php echo htmlentities($result->RegDate);?></td>
                                        <td><?php echo htmlentities($result->UpdationDate);?></td>
                                    </tr>
                                <?php $cnt=$cnt+1; } }?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!--inner block start here-->
            <div class="inner-block"></div>
            <!--inner block end here-->
            
            <!--copy rights start here-->
            <?php include('includes/footer.php');?>
            <!--COPY rights end here-->
        </div>
    </div>
    <!--//content-inner-->
    
    <div class="clearfix"></div>
</div>

<script>
$(document).ready(function() {
    // Sticky nav
    var navoffeset = $(".header-main").offset().top;
    $(window).scroll(function(){
        var scrollpos = $(window).scrollTop(); 
        if(scrollpos >= navoffeset){
            $(".header-main").addClass("fixed");
        } else {
            $(".header-main").removeClass("fixed");
        }
    });
    
    // Sidebar toggle
    var toggle = true;
    $(".sidebar-icon").click(function() {                
        if (toggle) {
            $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
            $("#menu span").css({"position":"absolute"});
        } else {
            $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
            setTimeout(function() {
                $("#menu span").css({"position":"relative"});
            }, 400);
        }
        toggle = !toggle;
    });
});
</script>

</body>
</html>
<?php } ?>