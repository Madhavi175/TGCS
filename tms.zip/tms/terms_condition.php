<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>TGCS | Terms & Conditions</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- <link href="css/style.css" rel='stylesheet' type='text/css' /> -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style>
    :root {
        --primary-color: #2A5C82;
        --secondary-color: #39A2DB;
        --text-color: #3A3A3A;
    }

    .terms-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 2rem;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }

    .terms-header {
        text-align: center;
        margin-bottom: 3rem;
        animation: fadeInDown 0.8s ease;
    }

    .terms-section {
        margin: 2.5rem 0;
        padding: 1.5rem;
        background: #f8f9fa;
        border-radius: 8px;
        transition: transform 0.3s ease;
        animation: slideInLeft 0.6s ease;
    }

    .terms-section:hover {
        transform: translateY(-3px);
    }

    .section-title {
        color: var(--primary-color);
        margin-bottom: 1.2rem;
        display: flex;
        align-items: center;
        gap: 0.8rem;
    }

    .section-title i {
        font-size: 1.4rem;
    }

    .highlight {
        color: var(--secondary-color);
        font-weight: 600;
    }

    .effective-date {
        text-align: center;
        margin-top: 3rem;
        padding: 1rem;
        background: #e9f5ff;
        border-radius: 6px;
        animation: fadeInUp 0.8s ease;
    }

    @keyframes fadeInDown {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes slideInLeft {
        from { opacity: 0; transform: translateX(-20px); }
        to { opacity: 1; transform: translateX(0); }
    }

    @media (max-width: 768px) {
        .terms-container {
            padding: 1rem;
            margin: 1rem;
        }

        .terms-section {
            margin: 1.5rem 0;
            padding: 1rem;
        }

        .section-title {
            font-size: 1.2rem;
        }
    }

    @media (max-width: 480px) {
        .terms-header h1 {
            font-size: 1.8rem;
        }

        .section-title {
            flex-direction: column;
            align-items: flex-start;
        }
    }

    .nav-links {
        position: sticky;
        top: 20px;
        background: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .nav-links a {
        display: block;
        padding: 0.5rem;
        color: var(--text-color);
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .nav-links a:hover {
        color: var(--secondary-color);
        padding-left: 1rem;
    }
</style>
</head>
<body>
<?php include('includes/header.php'); ?>

<div class="terms-container">
    <div class="terms-header">
        <h1>Terms & Conditions</h1>
        <p>Last Updated: <?php echo date('F j, Y'); ?></p>
    </div>

    <div class="nav-links">
        <a href="#acceptance">1. Acceptance of Terms</a>
        <a href="#services">2. Services Overview</a>
        <a href="#user-responsibilities">3. User Responsibilities</a>
        <a href="#guide-obligations">4. Guide Obligations</a>
        <a href="#payments">5. Payments & Fees</a>
    </div>

    <section id="acceptance" class="terms-section">
        <h2 class="section-title"><i class="fas fa-check-circle"></i>1. Acceptance of Terms</h2>
        <p>By accessing or using the TGCS platform, you agree to be bound by these Terms. We reserve the right to modify these terms at any time. Continued use after changes constitutes acceptance.</p>
    </section>

    <section id="services" class="terms-section">
        <h2 class="section-title"><i class="fas fa-concierge-bell"></i>2. Services Overview</h2>
        <p>TGCS provides a platform connecting travelers with professional local guides. We facilitate bookings but are not responsible for guide services. All guides are verified professionals with proper certifications.</p>
    </section>

    <section id="user-responsibilities" class="terms-section">
        <h2 class="section-title"><i class="fas fa-user-shield"></i>3. User Responsibilities</h2>
        <ul>
            <li>Provide accurate personal and payment information</li>
            <li>Respect local cultures and regulations</li>
            <li>Timely communication with guides</li>
            <li>Report any issues within 24 hours of service</li>
        </ul>
    </section>

    <section id="guide-obligations" class="terms-section">
        <h2 class="section-title"><i class="fas fa-id-card"></i>4. Guide Obligations</h2>
        <ul>
            <li>Maintain professional certifications</li>
            <li>Provide accurate availability information</li>
            <li>Adhere to safety protocols</li>
            <li>Respond to bookings within 12 hours</li>
        </ul>
    </section>

    <section id="payments" class="terms-section">
        <h2 class="section-title"><i class="fas fa-credit-card"></i>5. Payments & Fees</h2>
        <p><span class="highlight">Service Fee:</span> 15% of booking value<br>
        <span class="highlight">Cancellations:</span> Full refund if cancelled 72hrs prior<br>
        <span class="highlight">Payment Methods:</span> Credit/Debit Cards, UPI, Net Banking</p>
    </section>

    <div class="effective-date">
        <p>These terms are effective as of <?php echo date('F j, Y'); ?><br>
        Contact: legal@tgcs.in for any queries</p>
    </div>
</div>

<?php include('includes/footer.php'); ?>

<script>
    // Add smooth scroll behavior
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        });
    });

    // Add section hover effects
    document.querySelectorAll('.terms-section').forEach(section => {
        section.addEventListener('mouseover', () => {
            section.style.transform = 'translateY(-5px)';
        });
        section.addEventListener('mouseout', () => {
            section.style.transform = 'translateY(0)';
        });
    });
</script>
</body>
</html>