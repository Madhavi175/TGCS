<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>| Tour Guide Connect System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- <link href="css/style.css" rel='stylesheet' type='text/css' /> -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<style>
  /* Container */
.container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
}

/* Card styles */
.card {
    width: 320px;
    height: 200px;
    perspective: 1000px;
    position: relative;
    margin-top: 10%;
}

.card-inner {
    width: 100%;
    height: 100%;
    position: relative;
    transform-style: preserve-3d;
    transition: transform 0.6s ease-in-out;
}

.card:hover .card-inner {
    transform: rotateY(180deg);
}

/* Front and Back styles */
.card-front, .card-back {
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 10px;
    backface-visibility: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    padding: 20px;
    text-align: center;
    transition: box-shadow 0.3s ease-in-out;
}

/* Front side */
.card-front {
    background: linear-gradient(135deg, #23a6d5, #3586ff);
    color: white;
}
.card-front i {
    font-size: 40px;
    margin-bottom: 10px;
}

/* Back side */
.card-back {
    background: linear-gradient(135deg, #37474F, #263238);
    color: white;
    transform: rotateY(180deg);
}

.card-back a {
    margin-top: 15px;
    text-decoration: none;
    color: #FFEB3B;
    font-weight: bold;
    padding: 8px 16px;
    border: 2px solid #FFEB3B;
    border-radius: 5px;
    transition: background 0.3s ease-in-out, color 0.3s ease-in-out;
}

.card-back a:hover {
    background: #FFEB3B;
    color: #000;
}

/* Responsive */
@media (max-width: 768px) {
    .container {
        flex-direction: column;
        align-items: center;
    }
}
/*-- /rupes --*/

/*-- routes --*/
/* General styles for the routes container */
/* General routes container styling */
.routes {
    padding: 50px 0;
    /* background: #f7f7f7; */
    text-align: center;
}

/* Styling for individual icon containers */
.routes-left {
    background: #e63946; /* A vibrant red color for the icon background */
    padding: 20px;
    border-radius: 50%;
    margin: 20px;
    transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
    display: inline-block;
}

/* Hover effect on the icons (scale and shadow effect) */
.routes-left:hover {
    transform: scale(1.2); /* Slightly increase the size */
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2); /* Add shadow for 3D effect */
    background: #ff5f5f; /* Change background color on hover */
}

/* Styling for the icons */
.rou-left i {
    font-size: 3rem;
    color: white;
    transition: transform 0.3s ease, color 0.3s ease;
}

/* Add hover effect on icons */
.routes-left:hover i {
    transform: rotate(360deg); /* Rotate the icon on hover */
    color: #fff; /* Keep the icon color white */
}

/* Fade-in animations for the icons */
.wow.fadeInRight {
    animation: fadeInRight 1s ease-out;
}

@keyframes fadeInRight {
    from {
        opacity: 0;
        transform: translateX(50px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}


/*-- /routes --*/
/*-- holiday --*/
/* General Styling */


/* Container */
.holiday {
    max-width: 1200px;
    margin: auto;
    padding: 40px 15px;
    text-align: center;
}

/* Heading styling */
.holiday h3 {
    font-family: 'Arial', sans-serif;
    font-size: 2rem;
    color: gold;
    margin-bottom: 30px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 2px;
    position: relative;
    margin-right: 78%;
}

/* Adding a bottom border to the heading for some separation */
.holiday h3::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 3px;
    background: #e63946; /* A strong color for the line under the heading */
    border-radius: 5px;
}
/* Card Layout */
.rom-btm {
    display: flex;
    align-items: center;
    background: white;
    width: 100%;
    height: 500%;
    border-radius: 15px 15px 30px 30px;
     /* Rounded bottom corners */
     border: 5px solid rgb(32, 82, 139);
    overflow: hidden;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
    margin: 20px auto;
    transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
    padding: 20px;
}

.rom-btm:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
}


/* Half-Circle Image */
.room-left {
    flex: 1;
    position: relative;
    width: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
}

.room-left img {
    width: 180px;
    height: 180px;
    object-fit: cover;
    border-radius: 100px 100px 0 0; /* Half-circle effect */
    border: 5px solid rgb(32, 82, 139);
    background: #fff;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

/* Card Content */
.room-midle {
    flex: 2;
    padding: 20px;
    text-align: left;
}

.room-midle h4 {
    font-size: 20px;
    font-weight: bold;
    color: #0A1828;
    margin-bottom: 10px;
}

.room-midle h6 {
    font-size: 14px;
    color: #666;
    margin-bottom: 5px;
}

.room-midle p {
    font-size: 14px;
    color: #444;
    line-height: 1.6;
}

/* Pricing & Circular CTA */
.room-right {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 20px;
    text-align: center;
}

.room-right h5 {
    font-size: 18px;
    font-weight: bold;
    color: #E63946;
    margin-bottom: 10px;
}

/* Circular Button */
.circle-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 60px; /* Circular Shape */
    height: 60px; /* Circular Shape */
    text-decoration: none;
    font-size: 14px;
    font-weight: bold;
    text-transform: uppercase;
    border-radius: 50%;
    background: linear-gradient(135deg, #6a11cb, #2575fc, #ff4e50, #f8b400); /* Gradient Mix */
    color: #fff;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease-in-out;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

/* Hover Effect */
.circle-btn:hover {
    background: linear-gradient(135deg, #f8b400, #ff4e50, #2575fc, #6a11cb); /* Reverse Gradient */
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
    transform: scale(1.1);
}

/* Ripple Effect */
.circle-btn::before {
    content: "";
    position: absolute;
    width: 300%;
    height: 300%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.2) 10%, transparent 70%);
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0);
    opacity: 0;
    transition: all 0.6s ease-in-out;
}

.circle-btn:active::before {
    transform: translate(-50%, -50%) scale(1);
    opacity: 1;
}

/* Responsive Styling */
@media (max-width: 768px) {
    .circle-btn {
        width: 50px;
        height: 50px;
        font-size: 12px;
    }
}

/* Modern Gradient Button */
.view1 {
    text-decoration: none;
    font-size: 16px;
    font-weight: bold;
    text-transform: uppercase;
    padding: 12px 24px;
    border-radius: 50px;
    background: linear-gradient(135deg, #F8B400, #FF4E50); /* Gold to Red */
    color: #fff;
    position: relative;
    display: inline-block;
    outline-style: dotted; /* A series of dashes */
  outline-color: #feb47b;
    
    overflow: hidden;
    transition: all 0.3s ease-in-out;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

/* Hover Effect */
.view1:hover {
    background: linear-gradient(135deg, #FF4E50, #F8B400); /* Reverse Gradient */
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
    transform: translateY(-3px);
}

/* Ripple Effect */
.view1::before {
    content: "";
    position: absolute;
    width: 300%;
    height: 300%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.2) 10%, transparent 70%);
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0);
    opacity: 0;
    transition: all 0.6s ease-in-out;
}

.view1:active::before {
    transform: translate(-50%, -50%) scale(1);
    opacity: 1;
}

/* Responsive Styling */
@media (max-width: 768px) {
    .view1 {
        padding: 10px 20px;
        font-size: 14px;
    }
}


/* Responsive Design */
@media (max-width: 768px) {
    .rom-btm {
        flex-direction: column;
        text-align: center;
    }

    .room-left {
        order: -1;
    }

    .room-left img {
        border-radius: 50%;
    }

    .room-midle,
    .room-right {
        padding: 15px;
    }
}

    

	
  .box-container {
      position: absolute;
      top: 30%;
      left: 70%;
      display:grid;
     
      grid-template-columns: repeat(6, 50px); /* 6 columns of small boxes */
      grid-template-rows: repeat(6, 50px); /* 6 rows of small boxes */
      gap: 10px; /* Spacing between the boxes */
    }

    /* Individual small boxes */
    .box {
      width: 50px;
      height: 50px;
      background-color:#0FFCBE; /* Tomato color */
      opacity: 0.8; /* Optional: make the boxes semi-transparent */
      border-radius: 8px; /* Rounded corners */
    }

    /* Randomizing box colors */
    .box:nth-child(odd) {
      background-color:#00ABE4; /* Blue-grey color */
    }
    .box:nth-child(3n) {
      background-color:white; /* Gold color */
    }
    .box:nth-child(5n) {
      background-color: #BAFF39; /* Electric blue color */
    }

.grid-background {
    width: 100%;
    padding-top: 100px;
    padding-right: 24px;
    padding-left: 24px;
    margin-top: 0;
}
/* About Section Layout */
.about-section {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 40px;

    max-width: 1200px;
    margin: 80px auto 0; /* Adjust based on your header height */
    padding: 60px 20px;
   
}


/* Left Content Styling */
.about-content {
    flex: 1;
    max-width: 600px;
    color: #fff;
}

.about-content h2 {
    font-size: 2.5em;
    margin-bottom: 20px;
    color: #00FFD1;
}

.about-features {
    list-style: none;
    padding: 0;
    margin: 25px 0;
}

.about-features li {
    margin: 15px 0;
    padding-left: 30px;
    position: relative;
    font-size: 1.1em;
}

.about-features li:before {
    content: "✓";
    color: #00FFD1;
    position: absolute;
    left: 0;
    font-size: 1.2em;
}

/* Right Card Styling */
.about-card-container {
    flex: 0 1 500px;
    position: relative;
}

.material-card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

.card-top {
    position: relative;
    height: 180px;
    background: radial-gradient(circle at 50% 0%, #00A8E8 0%, #0A1828 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    clip-path: ellipse(100% 90% at 50% 0%);
}

.card-icon {
    width: 60px;
    height: 60px;
    background: #00FFD1;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    margin-top: 90px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 255, 209, 0.3);
}

.card-icon i {
    color: #0A1828;
    font-size: 24px;
    transition: transform 0.3s ease;
}

.card-content {
    padding: 30px;
    text-align: center;
    
}

.card-text h3 {
    color: #0A1828;
    margin-bottom: 15px;
    font-size: 1.5em;
}

.card-menu {
    list-style: none;
    padding: 0;
    margin: 20px 0 0;
    max-height: 0;
    overflow: hidden;
    transition: all 0.4s ease;
}

.material-card.active .card-menu {
    max-height: 300px;
}

.card-menu li {
    padding: 12px 0;
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s ease;
}

.material-card.active .card-menu li {
    opacity: 1;
    transform: translateY(0);
}

.card-menu a {
    color: #0A1828;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 10px;
    justify-content: center;
    transition: all 0.3s ease;
}

.card-menu a:hover {
    color: #00A8E8;
}

/* Responsive Design */
@media (max-width: 768px) {
    .about-section {
        flex-direction: column;
        padding: 40px 15px;
    }
    
    .about-card-container {
        width: 100%;
        max-width: 100%;
    }
    
    .card-top {
        height: 150px;
    }
}
/* Chat Button Styles */
/* .chat-btn {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #4ABDAC;
    color: white;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    transition: all 0.3s ease;
    z-index: 1000;
}

.chat-btn:hover {
    transform: scale(1.1);
    background: #378f80;
} */

/* Chat Box */
/* .chat-box {
    position: fixed;
    bottom: 80px;
    right: 20px;
    width: 350px;
    background: white;
    border-radius: 15px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.15);
    display: none;
    z-index: 1000;
}

.chat-header {
    background: #4ABDAC;
    color: white;
    padding: 15px;
    border-radius: 15px 15px 0 0;
}

.chat-body {
    height: 400px;
    overflow-y: auto;
    padding: 15px;
}

.chat-input {
    padding: 15px;
    border-top: 1px solid #eee;
}

.chat-message {
    margin-bottom: 15px;
    padding: 10px;
    border-radius: 8px;
    background: #f5f5f5;
} */
</style>
<!--Start of Tawk.to Script-->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/67f1652d2be648190d4fa386/1io3f6mn2';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!--End of Tawk.to Script-->

</head>
<body style="background: linear-gradient(135deg, #0A1828, #112A46, #00A8E8);">
<?php include('includes/header.php');?>


  <div class="background-shape">
  
</div>

<section class="about-section">
    <!-- Left Content -->
    <div class="about-content">
        <h2>About Tour Guide Connect</h2>
        <p>Your premier platform connecting travelers with expert local guides for authentic experiences.</p>
        
        <ul class="about-features">
            <li>500+ Verified Local Guides</li>
            <li>Customizable Tour Packages</li>
            <li>Instant Booking Confirmation</li>
            <li>Multilingual Support</li>
            <li>24/7 Customer Service</li>
        </ul>
        
        <p>Founded in 2023, we bridge the gap between travelers and local experts, creating meaningful connections and unforgettable journeys.</p>
    </div>

    <!-- Right Card -->
    <div class="about-card-container">
        <div class="material-card">
            <div class="card-top">
                <div class="card-icon" onclick="toggleCard()">
                    <i class="fas fa-chevron-down"></i>
                </div>
            </div>
            <div class="card-content">
                <div class="card-text">
                    <h3>Quick Actions</h3>
                    <p>Tap to explore more options</p>
                </div>
                <ul class="card-menu">
                    <li><a href="privacy.php"><i class="fas fa-shield-alt"></i>Privacy Policy</a></li>
                   
                    <li><a href="package-list.php"><i class="fas fa-map-marked-alt"></i>Destinations</a></li>
                    <li><i class="fas fa-user-check"></i><b><U>Become a Guide</U></b></li>
                </ul>
            </div>
        </div>
    </div>
</section>
  <div class="container">
    <!-- Card 1 -->
    <div class="card">
        <div class="card-inner">
            <div class="card-front">
                <div>
                    <i class="fa fa-plane"></i>
                    <h3>UP TO USD. 50 OFF</h3>
                    <p>Travel Smart & Save More</p>
                </div>
            </div>
            <div class="card-back">
                <div>
                    <h3>Exclusive Travel Deal</h3>
                    <p>Book your tickets now and enjoy discounts.</p>
                    <a href="package-list.php">View Offer</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2 -->
    <div class="card">
        <div class="card-inner">
            <div class="card-front">
                <div>
                    <i class="fa fa-home"></i>
                    <h3>UP TO 70% OFF Fast</h3>
                    <p>Best Deals </p>
                </div>
            </div>
            <div class="card-back">
                <div>
                    <h3>Sigin-up</h3>
                    <p>Book your dream stay with massive discounts.</p>
                    <a href="#" data-toggle="modal" data-target="#myModal">View Offer</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3 -->
    <!-- <div class="card">
        <div class="card-inner">
            <div class="card-front">
                <div>
                    <i class="fa fa-mobile"></i>
                    <h3>FLAT USD. 50 OFF</h3>
                    <p>Special Offer on Mobile App</p>
                </div>
            </div>
            <div class="card-back">
                <div>
                    <h3>Exclusive App Deal</h3>
                    <p>Use our app for additional discounts.</p>
                    <a href="offers.html">Download App</a>
                </div>
            </div>
        </div>
    </div> -->
</div>

<!--- /rupes ---->




<!---holiday---->
<div class="container">
	<div class="holiday">
	<h3>Package List</h3>					
<?php $sql = "SELECT * from tbltourpackages order by rand() limit 4";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{	?>
			<div class="rom-btm">
				<div class="col-md-3 room-left wow fadeInLeft animated" data-wow-delay=".5s">
					<img src="admin/pacakgeimages/<?php echo htmlentities($result->PackageImage);?>" class="img-responsive" alt="">
				</div>
				<div class="col-md-6 room-midle wow fadeInUp animated" data-wow-delay=".5s">
					<h4>Package Name: <?php echo htmlentities($result->PackageName);?></h4>
					<h6>Package Type : <?php echo htmlentities($result->PackageType);?></h6>
					<p><b>Package Location :</b> <?php echo htmlentities($result->PackageLocation);?></p>
					<p><b>Features</b> <?php echo htmlentities($result->PackageFetures);?></p>
				</div>
				<div class="col-md-3 room-right wow fadeInRight animated" data-wow-delay=".5s">
					<h5>USD <?php echo htmlentities($result->PackagePrice);?></h5>
					<a href="package-details.php?pkgid=<?php echo htmlentities($result->PackageId);?>" class="circle-btn">Details</a>

				</div>
				<div class="clearfix"></div>
			</div>

<?php }} ?>
<div><a href="package-list.php" class="view1">View More Packages</a></div>
</div>
	<div class="clearfix"></div>
	</div>
<!-- Chat HTML
<div class="chat-btn" onclick="toggleChat()">
    <i class="fa fa-comments fa-2x"></i>
</div>

<div class="chat-box" id="chatBox">
    <div class="chat-header">
        <h4 style="margin:0">Tour Guide Support</h4>
        <small>We're here to help!</small>
    </div>
    <div class="chat-body" id="chatBody">
        <div class="chat-message">
            <strong>Support:</strong> Hello! How can we help you today?
        </div>
    </div>
    <div class="chat-input">
        <textarea id="userMessage" rows="3" style="width:100%; margin-bottom:10px" 
                  placeholder="Type your message..."></textarea>
        <button class="btn" onclick="sendMessage()">Send</button>
    </div>
</div> -->
<!-- 
<script>
function toggleChat() {
    const chatBox = document.getElementById('chatBox');
    chatBox.style.display = chatBox.style.display === 'block' ? 'none' : 'block';
}
function sendMessage() {
    const message = document.getElementById('userMessage').value;
    if(message.trim() === '') return;

    const chatBody = document.getElementById('chatBody');
    const btn = document.querySelector('.chat-input button');
    
    // Add user message
    chatBody.innerHTML += `
        <div class="chat-message" style="background: #e3f2fd; text-align:right">
            <strong>You:</strong> ${message}
        </div>
    `;

    // Disable button during request
    btn.disabled = true;
    btn.innerHTML = 'Sending...';

    fetch('handle-chat.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({message: message})
    })
    .then(response => {
        if(!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(data => {
        chatBody.innerHTML += `
            <div class="chat-message">
                <strong>Support:</strong> ${data.response}
            </div>
        `;
    })
    .catch(error => {
        chatBody.innerHTML += `
            <div class="chat-message" style="background: #ffebee">
                <strong>Error:</strong> Could not send message. Please try again later.
            </div>
        `;
    })
    .finally(() => {
        btn.disabled = false;
        btn.innerHTML = 'Send';
        chatBody.scrollTop = chatBody.scrollHeight;
        document.getElementById('userMessage').value = '';
    });
}
</script> -->

    <script>
function toggleCard() {
    const card = document.querySelector('.material-card');
    card.classList.toggle('active');
    const icon = document.querySelector('.card-icon i');
    
    if(card.classList.contains('active')) {
        icon.style.transform = 'rotate(180deg)';
        // Add staggered animation for menu items
        document.querySelectorAll('.card-menu li').forEach((item, index) => {
            item.style.transitionDelay = `${index * 0.1}s`;
        });
    } else {
        icon.style.transform = 'rotate(0deg)';
        document.querySelectorAll('.card-menu li').forEach(item => {
            item.style.transitionDelay = '0s';
        });
    }
}
</script>

<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>			
<!-- //write us -->
</body>
</html>