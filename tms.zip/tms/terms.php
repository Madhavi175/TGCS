<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Terms and Conditions | Tour Guide Connect System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style>

:root {
    --primary-color: #002366;
    --secondary-color: #000080;
    --accent-color: #00A8E8;
    --text-color: #333333;
    --light-bg: #f8f9fa;
}

body {
    font-family: 'Open Sans', sans-serif;
    line-height: 1.8;
    color: var(--text-color);
    background-color: #ffffff;
    padding-top: 80px;
    font-size: 18px;
}

.terms-container {
    width: 100%;
    padding: 50px 5%;
    margin: 0;
}

.terms-header {
    text-align: center;
    margin-bottom: 60px;
    padding-bottom: 40px;
    border-bottom: 1px solid #eaeaea;
}

.terms-title {
    color: var(--primary-color);
    font-size: 2.8rem;
    font-weight: 700;
    margin-bottom: 20px;
    line-height: 1.3;
}

.last-updated {
    color: #666;
    font-size: 1.3rem;
    margin-bottom: 30px;
}

.terms-content {
    margin-bottom: 60px;
}

.section-title {
    color: var(--secondary-color);
    font-size: 2rem;
    margin: 50px 0 30px;
    padding-bottom: 10px;
    border-bottom: 2px solid var(--light-bg);
    font-weight: 600;
}

.terms-text {
    margin-bottom: 30px;
    font-size: 1.2rem;
    line-height: 1.9;
}

.contact-info {
    background-color: var(--light-bg);
    padding: 30px;
    border-radius: 8px;
    margin-top: 40px;
    border-left: 5px solid var(--accent-color);
    font-size: 1.15rem;
}

.contact-info p {
    margin-bottom: 15px;
}

.highlight {
    color: var(--primary-color);
    font-weight: 600;
}

@media (max-width: 768px) {
    body {
        font-size: 16px;
    }
    
    .terms-title {
        font-size: 2.2rem;
    }
    
    .section-title {
        font-size: 1.7rem;
    }
    
    .terms-text {
        font-size: 1.1rem;
    }
}

@media (max-width: 576px) {
    .terms-title {
        font-size: 2rem;
    }
    
    .section-title {
        font-size: 1.5rem;
    }
}

</style>
</head>
<body>

<?php include('includes/header.php');?>

<div class="terms-container">
    <div class="terms-header">
        <h1 class="terms-title">Terms and Conditions</h1>
        <p class="last-updated">Last Updated: <?php echo date("F j, Y"); ?></p>
        <p class="terms-text">Welcome to Tour Guide Connect System. Please read these Terms and Conditions carefully before using our services.</p>
    </div>

    <div class="terms-content">
        <h2 class="section-title">Introduction</h2>
        <p class="terms-text">These Terms and Conditions govern your relationship with Tour Guide Connect System regarding your use of our website and services. By accessing or using our platform, you agree to be bound by these Terms. If you disagree with any part of these Terms, you may not access our services.</p>
        
        <p class="terms-text">Our platform connects travelers with professional tour guides to enhance their travel experiences. We serve as an intermediary between travelers and independent tour guides, facilitating bookings and payments but not directly providing the tour services ourselves.</p>

        <h2 class="section-title">User Responsibilities</h2>
        <p class="terms-text">By using our services, you agree that you must be at least 18 years old to create an account or make bookings. Users under 18 may only use our services with parental or guardian supervision. You agree to provide accurate, current, and complete information during registration and when making bookings.</p>
        
        <p class="terms-text">You are solely responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree to use our services only for lawful purposes and in accordance with these Terms. You will not use our platform to distribute unsolicited commercial communications ("spam") or engage in fraudulent activities.</p>

        <h2 class="section-title">Booking and Payments</h2>
        <p class="terms-text">All tour bookings made through our platform are subject to availability at the time of booking confirmation. Prices displayed are subject to change without notice until a booking is confirmed. Each tour package has specific cancellation policies which will be clearly stated at the time of booking.</p>
        
        <p class="terms-text">We accept various payment methods including major credit cards and digital payment systems. All transactions are secured with SSL encryption. For cancellations made more than 48 hours before the scheduled tour, a full refund will be issued minus any processing fees. Cancellations within 48 hours are non-refundable.</p>

        <h2 class="section-title">Intellectual Property Rights</h2>
        <p class="terms-text">The content, organization, graphics, design, and other matters related to our platform are protected under applicable copyrights, trademarks, and other proprietary rights. All content on this website, including text, graphics, logos, button icons, images, audio clips, digital downloads, and software, is our property or licensed to us.</p>
        
        <p class="terms-text">You may not modify, reproduce, distribute, create derivative works of, publicly display or perform, or in any way exploit any of the content, in whole or in part, without our express written permission. The Tour Guide Connect System name and logo are our trademarks and may not be used in connection with any product or service without our prior written consent.</p>

        <h2 class="section-title">Limitation of Liability</h2>
        <p class="terms-text">To the maximum extent permitted by applicable law, we shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses resulting from your access to or use of or inability to access or use our services, any conduct or content of any third party on our services, any content obtained from our services, or unauthorized access, use, or alteration of your transmissions or content.</p>
        
        <p class="terms-text">We do not guarantee that our services will be uninterrupted, secure, or error-free. We make no warranty that the quality of any tours, services, information, or other material obtained through our platform will meet your expectations.</p>

        <h2 class="section-title">Privacy Policy</h2>
        <p class="terms-text">Your privacy is important to us. Our Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our platform. By using our services, you consent to the collection and use of your information in accordance with our Privacy Policy.</p>
        
        <p class="terms-text">We may collect personal information including but not limited to your name, email address, phone number, payment information, and travel preferences. This information is used to provide and improve our services, process transactions, and communicate with you.</p>

        <h2 class="section-title">Modifications to Terms</h2>
        <p class="terms-text">We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the updated Terms on our website and updating the "Last Updated" date. Your continued use of our services after any such changes constitutes your acceptance of the new Terms. If you do not agree to the new Terms, you must stop using our services.</p>

        <h2 class="section-title">Governing Law and Dispute Resolution</h2>
        <p class="terms-text">These Terms shall be governed by and construed in accordance with the laws of the jurisdiction where our company is registered, without regard to its conflict of law provisions. Any disputes arising out of or relating to these Terms or your use of our services shall be resolved through good faith negotiations between the parties. If such negotiations fail, the dispute shall be submitted to binding arbitration in accordance with the rules of the applicable arbitration association. The arbitration shall take place in Nagpur, and the language of arbitration shall be English.</p>

        <h2 class="section-title">Contact Information</h2>
        <p class="terms-text">If you have any questions about these Terms, please contact us at:</p>
        
        <div class="contact-info">
            <p><span class="highlight">Tour Guide Connect System</span></p>
            <p><span class="highlight">Email:</span> legal@tourguideconnect.com</p>
            <p><span class="highlight">Phone:</span> 222-77777</p>
            <p><span class="highlight">Address:</span> Nagpur, Maharashtra</p>
            <p><span class="highlight">Business Hours:</span> Monday-Friday, 9:00 AM to 6:00 PM</p>
        </div>
    </div>
</div>

<?php include('includes/footer.php');?>
<?php include('includes/signup.php');?>
<?php include('includes/signin.php');?>
<?php include('includes/write-us.php');?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>