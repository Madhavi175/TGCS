<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
{    
header('location:index.php');
}
else{
if(isset($_POST['submit5']))
{
$password=md5($_POST['password']);
$newpassword=md5($_POST['newpassword']);
$email=$_SESSION['login'];
    $sql ="SELECT Password FROM tblusers WHERE EmailId=:email and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
$con="update tblusers set Password=:newpassword where EmailId=:email";
$chngpwd1 = $dbh->prepare($con);
$chngpwd1-> bindParam(':email', $email, PDO::PARAM_STR);
$chngpwd1-> bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
$chngpwd1->execute();
$msg="Your Password succesfully changed";
}
else {
$error="Your current password is wrong";    
}
}

?>
<!DOCTYPE HTML>
<html>
<head>
<title>UTRS |User Travel Recommendation System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
    <script>
         new WOW().init();
    </script>
    <script type="text/javascript">
function valid()
{
if(document.chngpwd.newpassword.value!= document.chngpwd.confirmpassword.value)
{
alert("New Password and Confirm Password Field do not match  !!");
document.chngpwd.confirmpassword.focus();
return false;
}
return true;
}
</script>
<style>
   .header {
        position: fixed;
        top: 0;
        width: 100%;
        z-index: 1000;
        background: white;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .main-content {
        margin-top: 60px; /* Should match header height */
        padding: 20px 0;
    }

    .password-container {
        display: grid;
        grid-template-columns: 1fr 1fr;
        min-height: calc(100vh - 160px); /* Account for header + footer */
        background: #f8f9fa;
    }


    .password-illustration {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }

    .illustration-content {
        text-align: center;
        color: white;
        z-index: 1;
        padding: 2rem;
    }

    .password-form-section {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem;
    }

    .auth-card {
        background: white;
        padding: 2.5rem;
        border-radius: 16px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        width: 100%;
        max-width: 480px;
    }

    .form-title {
        font-size: 1.75rem;
        font-weight: 600;
        margin-bottom: 2rem;
        color: #1a1a1a;
        text-align: center;
    }

    .input-group {
        margin-bottom: 1.5rem;
    }

    .input-label {
        display: block;
        margin-bottom: 0.5rem;
        font-size: 0.9rem;
        color: #4a5568;
        font-weight: 500;
    }

    .form-input {
        width: 100%;
        padding: 0.875rem;
        border: 2px solid #e2e8f0;
        border-radius: 8px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }

    .form-input:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        outline: none;
    }

    .password-toggle {
        position: absolute;
        right: 12px;
        top: 38px;
        cursor: pointer;
        color: #718096;
    }

    .submit-btn {
        width: 100%;
        padding: 1rem;
        background: #667eea;
        color: white;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s ease;
        font-size: 1rem;
    }

    .submit-btn:hover {
        background: #5a67d8;
    }

    .errorWrap {
        padding: 1rem;
        margin-bottom: 1.5rem;
        background: #fee2e2;
        color: #dc2626;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        border-left: 4px solid #dc2626;
    }

    .succWrap {
        padding: 1rem;
        margin-bottom: 1.5rem;
        background: #dcfce7;
        color: #16a34a;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        border-left: 4px solid #16a34a;
    }

    @media (max-width: 768px) {
        .password-container {
            grid-template-columns: 1fr;
            min-height: auto;
        }
        
        .password-illustration {
            padding: 2rem;
            min-height: 300px;
        }
        
        .auth-card {
            padding: 1.5rem;
        }
    }
</style>
<body>
<?php include('includes/header.php');?>
<div class="main-content">
<div class="main-content">
   
        <!-- <div class="password-illustration wow fadeInLeft animated" data-wow-delay=".5s">
            <div class="illustration-content">
                <h2 style="font-size: 2.25rem; margin-bottom: 1rem;">Secure Your Account</h2>
                <p style="font-size: 1.1rem; opacity: 0.9;">Keep your travel experiences safe with a strong password</p>
            </div>
        </div> -->
        
        <div class="password-form-section wow fadeInRight animated" data-wow-delay=".5s">
            <div class="auth-card">
                <h3 class="form-title">Change Password</h3>
                
                <?php if($error){ ?>
                    <div class="errorWrap">
                        <i class="fa fa-exclamation-triangle"></i>
                        <?php echo htmlentities($error); ?>
                    </div>
                <?php } ?>
                
                <?php if($msg){ ?>
                    <div class="succWrap">
                        <i class="fa fa-check-circle"></i>
                        <?php echo htmlentities($msg); ?>
                    </div>
                <?php } ?>

                <form name="chngpwd" method="post" onSubmit="return valid();">
                    <div class="input-group">
                        <label class="input-label">Current Password</label>
                        <div style="position: relative;">
                            <input type="password" name="password" class="form-input" 
                                   placeholder="Enter current password" required>
                            <i class="fa fa-eye-slash password-toggle"></i>
                        </div>
                    </div>

                    <div class="input-group">
                        <label class="input-label">New Password</label>
                        <div style="position: relative;">
                            <input type="password" name="newpassword" id="newpassword" 
                                   class="form-input" placeholder="Create new password" required>
                            <i class="fa fa-eye-slash password-toggle"></i>
                        </div>
                    </div>

                    <div class="input-group">
                        <label class="input-label">Confirm Password</label>
                        <div style="position: relative;">
                            <input type="password" name="confirmpassword" class="form-input" 
                                   placeholder="Confirm new password" required>
                            <i class="fa fa-eye-slash password-toggle"></i>
                        </div>
                    </div>

                    <button type="submit" name="submit5" class="submit-btn">
                        Update Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<script>
document.querySelectorAll('.password-toggle').forEach(icon => {
    icon.addEventListener('click', (e) => {
        const input = e.target.previousElementSibling;
        const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
        input.setAttribute('type', type);
        e.target.classList.toggle('fa-eye-slash');
        e.target.classList.toggle('fa-eye');
    });
});
</script>

<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>            
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>            
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>
<?php } ?>