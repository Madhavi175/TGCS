<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0) {    
    header('location:index.php');
}
else {
if(isset($_POST['submit6'])) {
    $name=$_POST['name'];
    $mobileno=$_POST['mobileno'];
    $email=$_SESSION['login'];

    $sql="update tblusers set FullName=:name,MobileNumber=:mobileno where EmailId=:email";
    $query = $dbh->prepare($sql);
    $query->bindParam(':name',$name,PDO::PARAM_STR);
    $query->bindParam(':mobileno',$mobileno,PDO::PARAM_STR);
    $query->bindParam(':email',$email,PDO::PARAM_STR);
    $query->execute();
    $msg="Profile Updated Successfully";
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>UTRS | User Travel Recommendation System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Tourism Management System In PHP" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
    new WOW().init();
</script>

<style>
    body {
        background: linear-gradient(135deg, #0A1828, #112A46, #00A8E8);
        min-height: 100vh;
        font-family: 'Open Sans', sans-serif;
    }
    
    .errorWrap {
        padding: 15px;
        margin: 0 0 25px 0;
        background: #f8d7da;
        border-left: 4px solid #dc3545;
        color: #721c24;
        border-radius: 4px;
    }
    
    .succWrap {
        padding: 15px;
        margin: 0 0 25px 0;
        background: #d4edda;
        border-left: 4px solid #28a745;
        color: #155724;
        border-radius: 4px;
    }
    
    /* Profile Section */
    .profile-container {
        display: flex;
        max-width: 1200px;
        margin: 0 auto;
        padding: 120px 20px 60px;
        gap: 60px; /* Increased gap between columns */
    }
    
    .profile-form {
        flex: 1;
        background: rgba(255, 255, 255, 0.95);
        border-radius: 12px;
        padding: 50px; /* Increased padding */
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        margin-right: 20px; /* Additional right margin */
    }
    
    .profile-image {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin-left: 20px; /* Additional left margin */
    }
    
    .profile-img-wrapper {
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.95);
        border-radius: 12px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 50px; /* Increased padding */
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }
    
    .profile-img {
        width: 320px; /* Slightly larger image */
        height: 320px;
        object-fit: cover;
        border-radius: 50%;
        border: 6px solid #00A8E8; /* Thicker border */
        margin-bottom: 40px; /* More space below image */
    }
    
    .profile-title {
        color: #0a192f;
        font-size: 28px;
        margin-bottom: 30px;
        text-align: center;
        position: relative;
        padding-bottom: 15px;
    }
    
    .profile-title:after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 80px;
        height: 3px;
        background: #00A8E8;
    }
    
    .form-group {
        margin-bottom: 25px;
    }
    
    .form-label {
        display: block;
        margin-bottom: 8px;
        color: #2d3748;
        font-weight: 600;
        font-size: 14px;
    }
    
    .form-input {
        width: 100%;
        padding: 12px 15px;
        border: 2px solid #e2e8f0;
        border-radius: 8px;
        font-size: 15px;
        transition: all 0.3s;
        background: #f8fafc;
    }
    
    .form-input:focus {
        border-color: #00A8E8;
        box-shadow: 0 0 0 3px rgba(0, 168, 232, 0.1);
        outline: none;
    }
    
    .form-input[readonly] {
        background: #edf2f7;
        color: #718096;
    }
    
    .btn-update {
        background: #00A8E8;
        color: white;
        border: none;
        padding: 14px 25px;
        font-size: 16px;
        font-weight: 600;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s;
        width: 100%;
        margin-top: 20px;
    }
    
    .btn-update:hover {
        background: #0094C6;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 168, 232, 0.3);
    }
    
    .profile-meta {
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid #e2e8f0;
        font-size: 14px;
        color: #4a5568;
    }
    
    .profile-meta p {
        margin: 8px 0;
    }
    
    .profile-quote {
        font-style: italic;
        text-align: center;
        margin-top: 40px; /* More space above quote */
        color: #2d3748;
        font-size: 18px; /* Slightly larger font */
        line-height: 1.6;
        padding: 0 20px; /* Padding on sides */
    }
    
    /* Added a decorative element between columns */
    .profile-divider {
        position: relative;
    }
    
    .profile-divider:before {
        content: '';
        position: absolute;
        top: 50%;
        left: -30px;
        transform: translateY(-50%);
        width: 1px;
        height: 80%;
        background: rgba(255,255,255,0.3);
    }
    
    @media (max-width: 992px) {
        .profile-container {
            flex-direction: column;
            padding: 100px 15px 40px;
            gap: 40px;
        }
        
        .profile-form, .profile-img-wrapper {
            padding: 30px 25px;
            margin: 0;
        }
        
        .profile-img {
            width: 220px;
            height: 220px;
        }
        
        .profile-divider:before {
            display: none;
        }
    }
</style>
</head>
<body>

<?php include('includes/header.php');?>

<div class="profile-container wow fadeIn">
    <div class="profile-form">
        <h2 class="profile-title">My Profile</h2>
        
        <form name="chngpwd" method="post">
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

            <?php 
            $useremail=$_SESSION['login'];
            $sql = "SELECT * from tblusers where EmailId=:useremail";
            $query = $dbh -> prepare($sql);
            $query -> bindParam(':useremail',$useremail, PDO::PARAM_STR);
            $query->execute();
            $results=$query->fetchAll(PDO::FETCH_OBJ);
            $cnt=1;
            if($query->rowCount() > 0) {
                foreach($results as $result) { ?>
            
            <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" value="<?php echo htmlentities($result->FullName);?>" 
                       class="form-input" required>
            </div>

            <div class="form-group">
                <label class="form-label">Mobile Number</label>
                <input type="text" class="form-input" name="mobileno" maxlength="10" 
                       value="<?php echo htmlentities($result->MobileNumber);?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" class="form-input" name="email" 
                       value="<?php echo htmlentities($result->EmailId);?>" readonly>
            </div>

            <button type="submit" name="submit6" class="btn-update">
                Update Profile
            </button>
            
            <div class="profile-meta">
                <p><strong>Last Updated:</strong> <?php echo htmlentities($result->UpdationDate);?></p>
                <p><strong>Registration Date:</strong> <?php echo htmlentities($result->RegDate);?></p>
            </div>
            
            <?php }} ?>
        </form>
    </div>
    
    <div class="profile-image profile-divider">
        <div class="profile-img-wrapper">
            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Profile Image" class="profile-img">
            <div class="profile-quote">
                "Travel is the only thing you buy that makes you richer."
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>            
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>            
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
</body>
</html>
<?php } ?>