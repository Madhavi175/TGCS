<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>UTRS | Confirmation </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
</head>
<body>

<!-- Add this CSS style block in the head section -->
<style>
    /* Confirmation Animation */
    .confirmation-check {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: #4CAF50;
        margin: 20px auto;
        position: relative;
        animation: scaleIn 1s cubic-bezier(0.25, 0.46, 0.45, 0.94) both;
    } 
    .confirmation-check::after {
        content: '';
        position: absolute;
        left: 27px;
        top: 45px;
        width: 25px;
        height: 45px;
        border: solid white;
        border-width: 0 4px 4px 0;
        transform: rotate(45deg);
        animation: checkStrike 0.5s linear both;
        animation-delay: 0.5s;
    }

    @keyframes scaleIn {
        0% { transform: scale(0); opacity: 0; }
        100% { transform: scale(1); opacity: 1; }
    }

    @keyframes checkStrike {
        0% { height: 0; width: 0; opacity: 0; }
        50% { height: 25px; width: 0; opacity: 1; }
        100% { height: 45px; width: 25px; opacity: 1; }
    }

    /* Floating Cards */
    .destination-card {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 15px;
        padding: 20px;
        margin: 15px;
        transition: transform 0.3s ease;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }

    .destination-card:hover {
        transform: translateY(-10px);
    }

    /* Gradient Background Animation */
    .banner-1 {
        background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
    }
  @keyframes gradientBG {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
  /* Glassmorphism Effect */
    .con-top {
        background: rgba(255, 255, 255, 0.95) !important;
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 40px !important;
        box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
    }

    .feature-bubble {
        width: 120px;
        height: 120px;
        background: rgba(255, 255, 255, 0.9);
        border-radius: 50%;
        margin: 15px;
        padding: 20px;
        text-align: center;
        transition: all 0.3s ease;
    }
</style>
<?php include('includes/header.php');?>
<!-- Modified Body Content -->
<div class="banner-1">
    <div class="container">
        <h1 class="wow zoomIn animated" data-wow-delay=".5s">UTRS - Your Travel Journey Begins! ✈️</h1>
    </div>
</div>

<div class="contact">
    <div class="container">
        <div class="col-md-10 col-md-offset-1 contact-left">
            <!-- Confirmation Animation -->
            <div class="confirmation-check wow fadeIn" data-wow-delay="0.2s"></div>
            
            <!-- Main Message -->
            <div class="con-top animated wow fadeInUp" data-wow-delay="0.5s">
                <h2 class="text-success">🎉 Success! You're All Set!</h2>
                <h4><?php echo htmlentities($_SESSION['msg']);?></h4>
                <div class="wow fadeIn" data-wow-delay="1s">
                    <h3>Start Your Adventure Now!</h3>
                    <a href="package-list.php" class="btn btn-primary btn-lg">
                        Explore Travel Packages <i class="fa fa-arrow-right"></i>
                    </a>
                </div>
            </div>
                 <!-- Featured Destinations -->
            <div class="row wow fadeInUp" data-wow-delay="0.8s">
                <div class="col-md-12">
                    <h3 class="text-center">Popular Destinations ⛰️</h3>
                    <div class="row">
                        <div class="col-md-4 destination-card">
                            <img src="images/mountain.jpg" class="img-responsive" alt="Mountain Adventure">
                            <h4>Mountain Escapes</h4>
                            <p>Experience breathtaking views and fresh air</p>
                        </div>
                        <div class="col-md-4 destination-card">
                            <img src="images/beach.jpg" class="img-responsive" alt="Beach Vacation">
                            <h4>Tropical Beaches</h4>
                            <p>Relax on pristine sands with crystal clear waters</p>
                        </div>
                        <div class="col-md-4 destination-card">
                            <img src="images/city.jpg" class="img-responsive" alt="City Tour">
                            <h4>City Adventures</h4>
                            <p>Discover vibrant cultures and urban landscapes</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Features Grid -->
            <div class="row text-center wow fadeInUp" data-wow-delay="1s">
                <div class="col-md-3">
                    <div class="feature-bubble">
                        <i class="fa fa-compass fa-3x"></i>
                        <h5>Custom Plans</h5>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-bubble">
                        <i class="fa fa-lock fa-3x"></i>
                        <h5>Secure Booking</h5>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-bubble">
                        <i class="fa fa-star fa-3x"></i>
                        <h5>Premium Options</h5>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="feature-bubble">
                        <i class="fa fa-support fa-3x"></i>
                        <h5>24/7 Support</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>   $(document).ready(function(){
        $('.feature-bubble').hover(
            function(){ $(this).css('transform', 'translateY(-10px)'); },
            function(){ $(this).css('transform', 'translateY(0)'); }
        );
      
    });
</script>
<!--- /contact ---->
<?php include('includes/footer.php');?>
<!-- sign -->
<?php include('includes/signup.php');?>	
<!-- signin -->
<?php include('includes/signin.php');?>	
<!-- //signin -->
<?php include('includes/write-us.php');?>	
<!-- //write us -->
</body>
</html>