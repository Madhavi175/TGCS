
<?php
session_start();
error_reporting(0);
include('includes/config.php');
?><!DOCTYPE HTML>
<html>
<head>
<title>| Tour Guide Connect System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- <link href="css/style.css" rel='stylesheet' type='text/css' /> -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<style>/* About Section Layout */
.about-section {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 40px;
height: 600px;
    max-width: 1200px;
    margin: 80px auto 0; /* Adjust based on your header height */
    padding: 60px 20px;
}

/* Left Content Styling */
.about-content {
    flex: 1;
    max-width: 600px;
    color: #fff;
}

.about-content h2 {
    font-size: 2.5em;
    margin-bottom: 20px;
    color: #00FFD1;
}

.about-features {
    list-style: none;
    padding: 0;
    margin: 25px 0;
}

.about-features li {
    margin: 15px 0;
    padding-left: 30px;
    position: relative;
    font-size: 1.1em;
}

.about-features li:before {
    content: "✓";
    color: #00FFD1;
    position: absolute;
    left: 0;
    font-size: 1.2em;
}

/* Right Card Styling */
.about-card-container {
    flex: 0 1 500px;
    position: relative;
}

.material-card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

.card-top {
    position: relative;
    height: 180px;
    background: radial-gradient(circle at 50% 0%, #00A8E8 0%, #0A1828 100%);
    display: flex;
    align-items: center;
    justify-content: center;
}

.card-icon {
    width: 60px;
    height: 60px;
    background: #00FFD1;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0, 255, 209, 0.3);
}

.card-icon i {
    color: #0A1828;
    font-size: 24px;
    transition: transform 0.3s ease;
}

.card-content {
    padding: 30px;
    text-align: center;
}

.card-text h3 {
    color: #0A1828;
    margin-bottom: 15px;
    font-size: 1.5em;
}

.card-menu {
    list-style: none;
    padding: 0;
    margin: 20px 0 0;
    max-height: 0;
    overflow: hidden;
    transition: all 0.4s ease;
}

.material-card.active .card-menu {
    max-height: 300px;
}

.card-menu li {
    padding: 12px 0;
    opacity: 0;
    transform: translateY(10px);
    transition: all 0.3s ease;
}

.material-card.active .card-menu li {
    opacity: 1;
    transform: translateY(0);
}

.card-menu a {
    color: #0A1828;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 10px;
    justify-content: center;
    transition: all 0.3s ease;
}

.card-menu a:hover {
    color: #00A8E8;
}

/* Responsive Design */
@media (max-width: 768px) {
    .about-section {
        flex-direction: column;
        padding: 40px 15px;
    }
    
    .about-card-container {
        width: 100%;
        max-width: 100%;
    }
    
    .card-top {
        height: 150px;
    }
}
</style>

<body style="background: linear-gradient(135deg, #0A1828, #112A46, #00A8E8);
">
<?php include('includes/header.php');?>

<section class="about-section">
    <!-- Left Content -->
    <div class="about-content">
        <h2>About Tour Guide Connect</h2>
        <p>Your premier platform connecting travelers with expert local guides for authentic experiences.</p>
        
        <ul class="about-features">
            <li>500+ Verified Local Guides</li>
            <li>Customizable Tour Packages</li>
            <li>Instant Booking Confirmation</li>
            <li>Multilingual Support</li>
            <li>24/7 Customer Service</li>
        </ul>
        
        <p>Founded in 2023, we bridge the gap between travelers and local experts, creating meaningful connections and unforgettable journeys.</p>
    </div>

    <!-- Right Card -->
    <div class="about-card-container">
        <div class="material-card">
            <div class="card-top">
                <div class="card-icon" onclick="toggleCard()">
                    <i class="fas fa-chevron-down"></i>
                </div>
            </div>
            <div class="card-content">
                <div class="card-text">
                    <h3>Quick Actions</h3>
                    <p>Tap to explore more options</p>
                </div>
                <ul class="card-menu">
                    <li><a href="privacy.php"><i class="fas fa-shield-alt"></i>Privacy Policy</a></li>
                   
                    <li><a href="package-list.php"><i class="fas fa-map-marked-alt"></i>Destinations</a></li>
                    <li><i class="fas fa-user-check"></i><b><U>Become a Guide</U></b></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/67f1652d2be648190d4fa386/1io3f6mn2';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>

<script>
function toggleCard() {
    const card = document.querySelector('.material-card');
    card.classList.toggle('active');
    const icon = document.querySelector('.card-icon i');
    
    if(card.classList.contains('active')) {
        icon.style.transform = 'rotate(180deg)';
        // Add staggered animation for menu items
        document.querySelectorAll('.card-menu li').forEach((item, index) => {
            item.style.transitionDelay = `${index * 0.1}s`;
        });
    } else {
        icon.style.transform = 'rotate(0deg)';
        document.querySelectorAll('.card-menu li').forEach(item => {
            item.style.transitionDelay = '0s';
        });
    }
}
</script>
<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>			
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>			
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>			
<!-- //write us -->
</html>
