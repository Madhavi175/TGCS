<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$input = json_decode(file_get_contents('php://input'), true);

if(isset($input['message'])) {
    $message = trim($input['message']);
    
    // Simple chatbot logic
    $response = [
        'response' => "Thank you for your message! Our team will get back to you shortly."
    ];
    
    // Save to database (uncomment and configure if you want to store messages)
    
    include('includes/config.php');
    $sql = "INSERT INTO chat_messages (message, created_at) VALUES (:message, NOW())";
    $query = $dbh->prepare($sql);
    $query->bindParam(':message', $message, PDO::PARAM_STR);
    $query->execute();
    
    
    echo json_encode($response);
    exit;
}

echo json_encode(['response' => 'Invalid request']);
exit;
?>