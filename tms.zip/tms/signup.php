<?php
error_reporting(0);
if(isset($_POST['submit']))
{
$fname=$_POST['fname'];
$mnumber=$_POST['mobilenumber'];
$email=$_POST['email'];
$password=md5($_POST['password']);
$sql="INSERT INTO  tblusers(FullName,MobileNumber,EmailId,Password) VALUES(:fname,:mnumber,:email,:password)";
$query = $dbh->prepare($sql);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':mnumber',$mnumber,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':password',$password,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$_SESSION['msg']="You are Scuccessfully registered. Now you can login ";
header('location:thankyou.php');
}
else 
{
$_SESSION['msg']="Something went wrong. Please try again.";
header('location:thankyou.php');
}
}
?>
<!--Javascript for check email availabilty-->
<script>
function checkAvailability() {

$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'emailid='+$("#email").val(),
type: "POST",
success:function(data){
$("#user-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>
<style>
/* Main Modal Styling */
#myModal .modal-content {
    background: linear-gradient(135deg, #f8f9fa 0%, #e6f7ff 100%);
    border-radius: 12px;
    border: none;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

#myModal .modal-header {
    border-bottom: none;
    padding: 20px 20px 0;
    position: relative;
}

#myModal .modal-header .close {
    font-size: 28px;
    color: #6c757d;
    opacity: 1;
    text-shadow: none;
    position: absolute;
    right: 20px;
    top: 20px;
}

#myModal .modal-body {
    padding: 0 25px 25px;
}

/* Main Heading */
#myModal h3 {
    color: #20c997;
    font-size: 28px;
    font-weight: 700;
    text-align: center;
    margin-bottom: 25px;
    text-transform: uppercase;
    letter-spacing: 1px;
    background: linear-gradient(to right, #20c997, #17a2b8);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* Layout */
#myModal .login {
    display: flex;
    gap: 25px;
    margin-bottom: 25px;
}

#myModal .login-left {
    width: 40%;
    border-right: 1px solid rgba(0, 0, 0, 0.1);
    padding-right: 20px;
    display: flex;
    flex-direction: column;
}

#myModal .login-right {
    width: 60%;
    padding-left: 20px;
}

/* Social Buttons */
#myModal .login-left ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

#myModal .login-left li {
    margin-bottom: 15px;
}

#myModal .fb, #myModal .goog {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 12px;
    border-radius: 6px;
    color: white !important;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

#myModal .fb {
    background-color: #3b5998;
}

#myModal .fb:hover {
    background-color: #344e86;
    transform: translateY(-2px);
}

#myModal .goog {
    background-color: #dd4b39;
}

#myModal .goog:hover {
    background-color: #c23321;
    transform: translateY(-2px);
}

#myModal .fb i, #myModal .goog i {
    margin-right: 10px;
    font-size: 18px;
}

/* Form Elements */
#myModal input[type="text"],
#myModal input[type="password"] {
    width: 100%;
    padding: 12px 15px;
    margin-bottom: 15px;
    border: 1px solid #ced4da;
    border-radius: 6px;
    font-size: 14px;
    transition: all 0.3s;
    background-color: rgba(255, 255, 255, 0.8);
}

#myModal input[type="text"]:focus,
#myModal input[type="password"]:focus {
    border-color: #20c997;
    box-shadow: 0 0 0 0.2rem rgba(32, 201, 151, 0.25);
    outline: none;
}

#myModal #submit {
    background: linear-gradient(to right, #20c997, #17a2b8);
    color: white;
    padding: 12px;
    width: 100%;
    border: none;
    border-radius: 6px;
    font-weight: 600;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s;
    margin-top: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

#myModal #submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
}

/* Login Option */
#myModal .login-option {
    text-align: center;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid rgba(0, 0, 0, 0.1);
}

#myModal .login-option p {
    color: #6c757d;
    margin-bottom: 15px;
}

#myModal .login-btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: #f8f9fa;
    color: #495057;
    border: 1px solid #ced4da;
    border-radius: 6px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
}

#myModal .login-btn:hover {
    background-color: #e9ecef;
    transform: translateY(-2px);
}

/* Terms and Conditions */
#myModal .terms {
    text-align: center;
    font-size: 13px;
    color: #6c757d;
    margin-top: 20px;
}

#myModal .terms a {
    color: #20c997;
    text-decoration: none;
    font-weight: 600;
}

#myModal .terms a:hover {
    text-decoration: underline;
}

/* Availability Status */
#user-availability-status {
    display: block;
    margin: -10px 0 15px;
    font-size: 12px;
    min-height: 18px;
}

/* Responsive Design */
@media (max-width: 768px) {
    #myModal .login {
        flex-direction: column;
    }
    
    #myModal .login-left,
    #myModal .login-right {
        width: 100%;
        padding: 0;
        border-right: none;
    }
    
    #myModal .login-left {
        border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        padding-bottom: 20px;
        margin-bottom: 20px;
    }
}

</style>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
		<div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>                        
            </div>
            <section>
                <div class="modal-body modal-spa">
                    <div class="login-grids">
                        <div class="login">
                            <div class="login-left">
                                <h3>SIGN UP WITH</h3>
                                <ul>
                                    <li><a class="fb" href="#"><i class="fab fa-facebook-f"></i> Facebook</a></li>
                                    <li><a class="goog" href="#"><i class="fab fa-google"></i> Google</a></li>
                                </ul>
                                <div class="social-benefits">
                                    <p>Quick and easy registration</p>
                                    <p>No need to remember passwords</p>
                                </div>
                            </div>
                            <div class="login-right">
                                <form name="signup" method="post">
                                    <h3>CREATE YOUR ACCOUNT</h3>
                                    <input type="text" value="" placeholder="Full Name" name="fname" autocomplete="off" required>
                                    <input type="text" value="" placeholder="Mobile number" maxlength="10" name="mobilenumber" autocomplete="off" required>
                                    <input type="text" value="" placeholder="Email id" name="email" id="email" onBlur="checkAvailability()" autocomplete="off" required>    
                                    <span id="user-availability-status"></span> 
                                    <input type="password" value="" placeholder="Password" name="password" required>    
                                    <input type="submit" name="submit" id="submit" value="CREATE ACCOUNT">
                                </form>
                                <div class="login-option">
                                    <p>Already have an account?</p>
                                    <a href="#" class="login-btn" data-dismiss="modal" data-toggle="modal" data-target="#loginModal">LOGIN HERE</a>
                                </div>
                            </div>
                            <div class="clearfix"></div>                                
                        </div>
                        <div class="terms">
                            <p>By logging in you agree to our <a href="page.php?type=terms">Terms and Conditions</a> and <a href="page.php?type=privacy">Privacy Policy</a></p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<!-- Font Awesome for social icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
